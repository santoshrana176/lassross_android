package com.mindiii.lasross.session_api.prefs.remote;

import android.util.Log;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.BuildConfig;
import com.androidnetworking.common.ANRequest;
import com.androidnetworking.common.Priority;
import com.mindiii.lasross.helper.Constant;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import okhttp3.Cookie;
import okhttp3.CookieJar;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;

public class AppApiHelper implements ApiHelper{

    private final static  String TAG = AppApiHelper.class.getSimpleName();
    private static  AppApiHelper instance;
    private CookieJar cookieJar;

    public synchronized  static AppApiHelper getAppApiInstance(){
        if(instance == null){
            instance = new AppApiHelper();
        }
        return instance;
    }

    @Override
    public ANRequest doServerLogin(HashMap<String, String> params) {
        return AndroidNetworking.post(WebServices.WEB_LOGIN)
                .addBodyParameter(params)
                .setTag(TAG)
                .setPriority(Priority.MEDIUM)
                .build();
    }

    @Override
    public ANRequest doServerRegistration(HashMap<String, String> params) {
        return AndroidNetworking.post(WebServices.REGISTRATION_API)
                .addBodyParameter(params)
                .setTag(TAG)
                .setPriority(Priority.MEDIUM)
                .build();
    }


    @Override
    public ANRequest logout(HashMap<String, String> header) {
        return AndroidNetworking.post(WebServices.LOGOUT_API)
                .addHeaders(header)
                .setTag(TAG)
                .setPriority(Priority.MEDIUM)
                .build();
    }

    @Override
    public ANRequest getForgotPassword(HashMap<String, String> params) {
        return AndroidNetworking.post(WebServices.GET_FORGOT_PASSWORD)
                .addBodyParameter(params)
                .setTag(TAG)
                .setPriority(Priority.MEDIUM)
                .build();
    }

    @Override
    public ANRequest getHomeProductCategory(HashMap<String, String> params) {
        return AndroidNetworking.post(WebServices.GET_HOME_PRODUCT_CATEGORY)
                .addHeaders(params)
                .setTag(TAG)
                .setPriority(Priority.MEDIUM)
                .build();
    }

    @Override
    public ANRequest getHomeProduct(HashMap<String, String> params) {
        return AndroidNetworking.post(WebServices.GET_HOME_PRODUCT)
                .addHeaders(params)
                .setTag(TAG)
                .setPriority(Priority.MEDIUM)
                .build();
    }

    @Override
    public ANRequest getMenuList(HashMap<String, String> params) {
        return AndroidNetworking.post(WebServices.GET_MENU_LIST)
                .addHeaders(params)
                .setTag(TAG)
                .setPriority(Priority.MEDIUM)
                .build();
    }

    @Override
    public ANRequest getProductDetail(HashMap<String, String> header,HashMap<String, String> params) {
        return AndroidNetworking.post(WebServices.GET_PRODUCT_DETAIL)
                .addHeaders(header)
                .addBodyParameter(params)
                .setTag(TAG)
                .setPriority(Priority.MEDIUM)
                .build();
    }

    @Override
    public ANRequest getSocialLogin(HashMap<String, String> params) {
        return AndroidNetworking.post(WebServices.GET_SOCIAL_LOGIN)
                .addBodyParameter(params)
                .setTag(TAG)
                .setPriority(Priority.MEDIUM)
                .build();
    }

    @Override
    public ANRequest doProfileimageUpdate(HashMap<String, String>  header, HashMap<String, String> params) {
        return AndroidNetworking.post(WebServices.GET_PROFILE_IMAGE_UPDATE)
                .addBodyParameter(params)
                .setTag(TAG)
                .setPriority(Priority.MEDIUM)
                .build();
    }

    @Override
    public ANRequest doProfileUpdate(HashMap<String, String>  header, HashMap<String, String> params) {
        return AndroidNetworking.post(WebServices.GET_UPDATE_PROFILE)
                .addBodyParameter(params)
                .setTag(TAG)
                .setPriority(Priority.MEDIUM)
                .build();
    }

    @Override
    public ANRequest doChangePassword(HashMap<String, String>  header, HashMap<String, String> params) {
        return AndroidNetworking.post(WebServices.GET_CHANGE_PASSWORD)
                .addBodyParameter(params)
                .setTag(TAG)
                .setPriority(Priority.MEDIUM)
                .build();
    }

    @Override
    public ANRequest getUserProfile(HashMap<String, String> header, HashMap<String, String> params) {
        return AndroidNetworking.post(WebServices.GET_USER_PROFILE)
                .addBodyParameter(params)
                .addHeaders(header)
                .setTag(TAG)
                .setPriority(Priority.MEDIUM)
                .build();
    }

    @Override
    public ANRequest doAddToCart(HashMap<String, String> header, HashMap<String, String> params) {
        createCookie();
        OkHttpClient okHttpClient = new OkHttpClient.Builder()
                .cookieJar(cookieJar)
                .build();

        Log.d("HelloWorld", WebServices.GET_ADD_TO_CART);
        return AndroidNetworking.post(WebServices.GET_ADD_TO_CART)
                .addBodyParameter(params)
                .addHeaders(header)
                .setOkHttpClient(okHttpClient)
                .setTag(TAG)
                .setPriority(Priority.MEDIUM)
                .build();
    }

    @Override
    public ANRequest getCart(HashMap<String, String> header) {
        createCookie();
        OkHttpClient okHttpClient = new OkHttpClient.Builder()
                .cookieJar(cookieJar)
                .build();
        return AndroidNetworking.get(WebServices.GET_CART)
                .addHeaders(header)
                .setOkHttpClient(okHttpClient)
                .setTag(TAG)
                .setPriority(Priority.MEDIUM)
                .build();
    }

    @Override
    public ANRequest doRemoveCartItem(HashMap<String, String> header, HashMap<String, String> params) {
        createCookie();
        OkHttpClient okHttpClient = new OkHttpClient.Builder()
                .cookieJar(cookieJar)
                .build();
        return AndroidNetworking.post(WebServices.DO_REMOVE_CART_ITEM)
                .addHeaders(header)
                .addBodyParameter(params)
                .setOkHttpClient(okHttpClient)
                .setTag(TAG)
                .setPriority(Priority.MEDIUM)
                .build();
    }

    @Override
    public ANRequest doUpdateCartItem(HashMap<String, String> header, HashMap<String, String> params) {
        createCookie();
        OkHttpClient okHttpClient = new OkHttpClient.Builder()
                .cookieJar(cookieJar)
                .build();
        return AndroidNetworking.post(WebServices.DO_UPDATE_CART_ITEM)
                .addHeaders(header)
                .addBodyParameter(params)
                .setOkHttpClient(okHttpClient)
                .setTag(TAG)
                .setPriority(Priority.MEDIUM)
                .build();
    }

    private void createCookie() {
        if (cookieJar == null) {
            cookieJar = new CookieJar() {
                private final HashMap<String, List<Cookie>> cookieStore = new HashMap<>();
                @Override
                public void saveFromResponse(HttpUrl url, List<Cookie> cookies) {
                    cookieStore.put(url.host(), cookies);
                    Constant.cookieStoreTemp = new HashMap<>();
                    Constant.cookieStoreTemp = cookieStore;
                }

                @Override
                public List<Cookie> loadForRequest(HttpUrl url) {
                    List<Cookie> cookies = cookieStore.get(url.host());
                    return cookies != null ? cookies : new ArrayList<Cookie>();
                }
            };
        }
    }


}
