package com.mindiii.lasross.session_api.prefs.remote;

import com.androidnetworking.common.ANRequest;

import java.util.HashMap;

public interface ApiHelper {

    ANRequest doServerLogin(HashMap<String, String> params);

    ANRequest doServerRegistration(HashMap<String, String> params);

    ANRequest logout(HashMap<String, String> header);

    ANRequest getForgotPassword(HashMap<String, String> params);

    ANRequest getHomeProductCategory(HashMap<String, String> params);

    ANRequest getHomeProduct(HashMap<String, String> params);

    ANRequest getMenuList(HashMap<String, String> params);

    ANRequest getProductDetail(HashMap<String, String>  header,HashMap<String, String> params);

    ANRequest getSocialLogin(HashMap<String, String> params);

    ANRequest doProfileimageUpdate(HashMap<String, String>  header,HashMap<String, String> params);

    ANRequest doProfileUpdate(HashMap<String, String>  header,HashMap<String, String> params);

    ANRequest doChangePassword(HashMap<String, String>  header,HashMap<String, String> params);

    ANRequest getUserProfile(HashMap<String, String>  header,HashMap<String, String> params);

    ANRequest doAddToCart(HashMap<String, String>  header,HashMap<String, String> params);

    ANRequest getCart(HashMap<String, String>  header);

    ANRequest doRemoveCartItem(HashMap<String, String>  header,HashMap<String, String> params);

    ANRequest doUpdateCartItem(HashMap<String, String>  header,HashMap<String, String> params);
}
