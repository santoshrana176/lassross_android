package com.mindiii.lasross.userprofile.model;

public class Capabilities {
}
