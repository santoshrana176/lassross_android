package com.mindiii.lasross.model;

public class OrderStatus {

    String message, date, status;
}
