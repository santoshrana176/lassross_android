package com.mindiii.lasross.userprofile;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.RequiresApi;

import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.StringRequestListener;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.mindiii.lasross.R;
import com.mindiii.lasross.adapter.UserProfileAdapter;
import com.mindiii.lasross.base.BaseActivity;
import com.mindiii.lasross.editprofile.EditProfileActivity;
import com.mindiii.lasross.model.UserProfileModel;
import com.mindiii.lasross.sessionNew.Session;
import com.mindiii.lasross.userprofile.model.User;
import com.mindiii.lasross.userprofile.model.UserProfile;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class UserProfileActivity26 extends BaseActivity {

    private UserProfileAdapter userProfileAdapter;
    private Session session;
    private Gson gson;
    RecyclerView recyclerView;
    ImageView ivProfileEdit;
    ImageView iv_back_Icon;
    ImageView ivUserImage;
    TextView tvUserName;
    TextView tvAddress;
    List<UserProfileModel> list;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_profile_activity_layout_26);
        recyclerView = findViewById(R.id.recyclerView);
        ivProfileEdit = findViewById(R.id.ivProfileEdit);
        iv_back_Icon = findViewById(R.id.iv_back_Icon);
        ivUserImage = findViewById(R.id.ivUserImage);
        tvUserName = findViewById(R.id.tvUserName);
        tvAddress = findViewById(R.id.tvAddress);
        list = new ArrayList<>();
        session = new Session(this);

        GsonBuilder gsonBuilder = new GsonBuilder();
        gson = gsonBuilder.create();

        getUserProfileUpdate();

        if (!session.getDescription().isEmpty())
            tvAddress.setText(session.getDescription());
        else
            tvAddress.setText("N/A");

        Window window = this.getWindow();
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(this.getResources().getColor(R.color.home_header_bg1));

        /*if(!session.getProfile_image().isEmpty()){
            Picasso.with(this)
                    .load(session.getProfile_image())
                    .resize(600, 600)
                    .into(ivUserImage);
        }*/

        //tvUserName.setText(session.getFirst_name() +" "+ session.getLast_Name());

        iv_back_Icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        ivProfileEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(UserProfileActivity26.this, EditProfileActivity.class));
                finish();
            }
        });
    }

    public void getUserProfileUpdate() {
        final HashMap<String, String> paramas = new HashMap();
        paramas.put("cookie",session.getCookie());

        getDataManager().getUserProfile(getDataManager().getHeader(), paramas).getAsString(new StringRequestListener() {
            @Override
            public void onResponse(String response) {
                //Log.e("#############","aa gaya");
                UserProfile userProfile = gson.fromJson(response, UserProfile.class);

                User user = userProfile.getUser();
                Log.e("#############",user.getFirstname());

                tvUserName.setText(user.getFirstname() +" "+ user.getLastname());
                if(!user.getAvatar_url_full().isEmpty()){
                    Picasso.with(UserProfileActivity26.this)
                            .load(user.getAvatar_url_full())
                            .resize(600, 600)
                            .into(ivUserImage);
                }
            }

            @Override
            public void onError(ANError anError) {

            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}
