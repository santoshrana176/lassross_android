package com.mindiii.lasross.addtocart.common;

import com.mindiii.lasross.addtocart.model.SizeModel;

public class Common {
    public static SizeModel currentItem = null;
}
