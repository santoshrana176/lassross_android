package com.mindiii.lasross.addtocart.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.mindiii.lasross.R;
import com.mindiii.lasross.addtocart.model.SizeModel;
import com.mindiii.lasross.home.interfc.HeaderInterface;

import java.util.List;

public class SizeAdapter extends RecyclerView.Adapter<SizeAdapter.Holder> implements View.OnClickListener {

    private List<SizeModel> list;
    private Context context;
    private HeaderInterface headerInterface;


    public SizeAdapter(List<SizeModel> list, Context context, HeaderInterface headerInterface) {
        this.list = list;
        this.context = context;
        this.headerInterface = headerInterface;
    }

    @NonNull
    @Override
    public SizeAdapter.Holder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view;
        SizeAdapter.Holder holder;
        view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.size_adapter_layout, viewGroup, false);
        holder = new SizeAdapter.Holder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull final SizeAdapter.Holder holder, final int i) {
        final SizeModel itemList = list.get(i);
        switch (itemList.getSize().trim()) {
            case "Large":
                holder.tvSize.setText("L");
                break;
            case "Medium":
                holder.tvSize.setText("M");
                break;
            case "Small":
                holder.tvSize.setText("S");
                break;
        }

        
        if (list.get(i).isChecked()) {
            holder.tvSize.setBackgroundResource(R.drawable.small_size_border);
        } else {
            holder.tvSize.setBackgroundResource(R.drawable.dashed_border);
        }
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    @Override
    public void onClick(View view) {
    }

    public class Holder extends RecyclerView.ViewHolder implements View.OnClickListener {
        private TextView tvSize;
        private LinearLayout main_view;

        public Holder(@NonNull View itemView) {
            super(itemView);
            tvSize = itemView.findViewById(R.id.tvSize);
            main_view = itemView.findViewById(R.id.main_view);
            main_view.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            SizeModel sizeModel = list.get(getAdapterPosition());
            headerInterface.onClickListener(getAdapterPosition());

            switch (v.getId()) {
                case R.id.main_view:
                    for (int i = 0; i < list.size(); i++) {
                        list.get(i).setChecked(false);
                    }
                    sizeModel.setChecked(true);
                    notifyDataSetChanged();
                    break;
            }
        }
    }
}
