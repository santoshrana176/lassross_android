package com.mindiii.lasross.loginregistration.model;

public class User{
	private String firstname;
	private Capabilities capabilities;
	private String registered;
	private String description;
	private String nicename;
	private String avatar;
	private String url;
	private String lastname;
	private String avatarUrlFull;
	private String avatarUrlThumb;
	private String displayname;
	private String nickname;
	private int id;
	private String email;
	private String username;

	public void setFirstname(String firstname){
		this.firstname = firstname;
	}

	public String getFirstname(){
		return firstname;
	}

	public void setCapabilities(Capabilities capabilities){
		this.capabilities = capabilities;
	}

	public Capabilities getCapabilities(){
		return capabilities;
	}

	public void setRegistered(String registered){
		this.registered = registered;
	}

	public String getRegistered(){
		return registered;
	}

	public void setDescription(String description){
		this.description = description;
	}

	public String getDescription(){
		return description;
	}

	public void setNicename(String nicename){
		this.nicename = nicename;
	}

	public String getNicename(){
		return nicename;
	}

	public void setAvatar(String avatar){
		this.avatar = avatar;
	}

	public String getAvatar(){
		return avatar;
	}

	public void setUrl(String url){
		this.url = url;
	}

	public String getUrl(){
		return url;
	}

	public void setLastname(String lastname){
		this.lastname = lastname;
	}

	public String getLastname(){
		return lastname;
	}

	public void setAvatarUrlFull(String avatarUrlFull){
		this.avatarUrlFull = avatarUrlFull;
	}

	public String getAvatarUrlFull(){
		return avatarUrlFull;
	}

	public void setAvatarUrlThumb(String avatarUrlThumb){
		this.avatarUrlThumb = avatarUrlThumb;
	}

	public String getAvatarUrlThumb(){
		return avatarUrlThumb;
	}

	public void setDisplayname(String displayname){
		this.displayname = displayname;
	}

	public String getDisplayname(){
		return displayname;
	}

	public void setNickname(String nickname){
		this.nickname = nickname;
	}

	public String getNickname(){
		return nickname;
	}

	public void setId(int id){
		this.id = id;
	}

	public int getId(){
		return id;
	}

	public void setEmail(String email){
		this.email = email;
	}

	public String getEmail(){
		return email;
	}

	public void setUsername(String username){
		this.username = username;
	}

	public String getUsername(){
		return username;
	}

	@Override
 	public String toString(){
		return 
			"User{" + 
			"firstname = '" + firstname + '\'' + 
			",capabilities = '" + capabilities + '\'' + 
			",registered = '" + registered + '\'' + 
			",description = '" + description + '\'' + 
			",nicename = '" + nicename + '\'' + 
			",avatar = '" + avatar + '\'' + 
			",url = '" + url + '\'' + 
			",lastname = '" + lastname + '\'' + 
			",avatar_url_full = '" + avatarUrlFull + '\'' + 
			",avatar_url_thumb = '" + avatarUrlThumb + '\'' + 
			",displayname = '" + displayname + '\'' + 
			",nickname = '" + nickname + '\'' + 
			",id = '" + id + '\'' + 
			",email = '" + email + '\'' + 
			",username = '" + username + '\'' + 
			"}";
		}
}
