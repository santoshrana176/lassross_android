package com.mindiii.lasross.addtocart.model;

import java.util.List;

public class AvailableSize {


    private List<MediumBean> medium;
    private List<LargeBean> large;

    public List<MediumBean> getMedium() {
        return medium;
    }

    public void setMedium(List<MediumBean> medium) {
        this.medium = medium;
    }

    public List<LargeBean> getLarge() {
        return large;
    }

    public void setLarge(List<LargeBean> large) {
        this.large = large;
    }

    public static class MediumBean {
        private int variation_id;
        private String color;

        public int getVariation_id() {
            return variation_id;
        }

        public void setVariation_id(int variation_id) {
            this.variation_id = variation_id;
        }

        public String getColor() {
            return color;
        }

        public void setColor(String color) {
            this.color = color;
        }
    }

    public static class LargeBean {
        /**
         * variation_id : 1339
         * color : blue
         */

        private int variation_id;
        private String color;

        public int getVariation_id() {
            return variation_id;
        }

        public void setVariation_id(int variation_id) {
            this.variation_id = variation_id;
        }

        public String getColor() {
            return color;
        }

        public void setColor(String color) {
            this.color = color;
        }
    }
}
