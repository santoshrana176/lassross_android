package com.mindiii.lasross.session_api.prefs.remote;

import com.mindiii.lasross.BuildConfig;

public class WebServices {

    static final String WEB_LOGIN = BuildConfig.BASE_URL + "service/login";

    static final String REGISTRATION_API = BuildConfig.BASE_URL + "service/regisration";


    static final String LOGOUT_API = BuildConfig.BASE_URL + "service/logout";

    static final String GET_FORGOT_PASSWORD = BuildConfig.BASE_URL + "service/forgot_password";

    static final String GET_HOME_PRODUCT_CATEGORY = BuildConfig.BASE_URL + "product/productCategory";

    static final String GET_HOME_PRODUCT = BuildConfig.BASE_URL + "product/getProduct";

    static final String GET_MENU_LIST = BuildConfig.BASE_URL + "product/menuList";

    static final String GET_PRODUCT_DETAIL = BuildConfig.BASE_URL + "product/productDetail";

    static final String GET_SOCIAL_LOGIN = BuildConfig.BASE_URL + "service/socialLogin";

    static final String GET_UPDATE_PROFILE = BuildConfig.BASE_URL + "service/update_profile";

    static final String GET_PROFILE_IMAGE_UPDATE = BuildConfig.BASE_URL + "service/update_user_avatar";

    static final String GET_CHANGE_PASSWORD = BuildConfig.BASE_URL + "service/change_password";

    static final String GET_USER_PROFILE = BuildConfig.BASE_URL + "service/get_userProfile";

    static final String GET_ADD_TO_CART = BuildConfig.BASE_URL + "product/addCart";

    static final String GET_CART = BuildConfig.BASE_URL + "product/getCart";

    static final String DO_REMOVE_CART_ITEM = BuildConfig.BASE_URL + "product/removeCartItem";

    static final String DO_UPDATE_CART_ITEM = BuildConfig.BASE_URL + "product/updateCart";
}
