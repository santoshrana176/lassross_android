package com.mindiii.lasross.sessionNew;

import java.io.Serializable;

public class UserInfo implements Serializable {

    public String userId= "";
    public String cookie= "";
    public String first_name= "";
    public String last_name= "";
    public String email= "";
    public String profile_image= "";
    public String social_id= "";
    public String description= "";
    public String facebook= "";
    public String gmail= "";
    public String social_type= "";
    public boolean isLoggedIn = false;

}
