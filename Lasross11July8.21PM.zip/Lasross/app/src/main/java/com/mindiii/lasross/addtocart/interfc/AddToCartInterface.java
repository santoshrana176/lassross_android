package com.mindiii.lasross.addtocart.interfc;

import android.view.View;

public interface AddToCartInterface {

    interface ClickListener {
        void onClickListener(int position);
        void onClickPlusMinus(int position, int quantity);
    }

}