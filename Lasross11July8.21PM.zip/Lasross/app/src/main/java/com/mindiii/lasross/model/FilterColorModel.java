package com.mindiii.lasross.model;

public class FilterColorModel {
}
