package com.mindiii.lasross.sessionNew;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import com.mindiii.lasross.loginregistration.LoginActivity;
import com.mindiii.lasross.session_api.prefs.newPrefs.PreferencesHelper;

import java.util.HashMap;

public class Session implements PreferencesHelper {

    private static final String REMEMBER_PWD = "password";
    private static final String REMEMBER_NAME = "email";
    private Context context;
    private static SharedPreferences sharedPreferences;
    private static SharedPreferences.Editor editor;
    private static SharedPreferences.Editor editorRem;

    private static final String IS_LOGGEDIN = "isLoggedIn";
    private static final String AUTH_TOKEN = "authToken";

    private static final String Filter_id = "filterId";
    public SharedPreferences myprefRemember;
    private static final String PREF_NAMELAN = "lan";


    public Session(Context context) {
        this.context = context;
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        editor = sharedPreferences.edit();

        myprefRemember = this.context.getSharedPreferences(PREF_NAMELAN, Context.MODE_PRIVATE);
        editorRem = myprefRemember.edit();
        editorRem.apply();

    }

    public void createSession(UserInfo userInfo) {
        editor.putString("userId", userInfo.userId);
        editor.putString("cookie", userInfo.cookie);
        editor.putString("authToken", userInfo.cookie);
        editor.putString("first_name", userInfo.first_name);
        editor.putString("last_name", userInfo.last_name);
        editor.putString("email", userInfo.email);
        editor.putString("profile_image", userInfo.profile_image);
        editor.putString("social_id", userInfo.social_id);
        editor.putString("description", userInfo.description);
        editor.putString("social_type", userInfo.social_type);

        editor.putBoolean(IS_LOGGEDIN, true);

        editor.commit();
    }

    public void session_for_Login(String email, String password) {
        editorRem.putString("email", email);
        editorRem.putString("password", password);
        editorRem.commit();
    }

    public String getFirst_name() {
        return sharedPreferences.getString("first_name", "");
    }

    public String getLast_Name() {
        return sharedPreferences.getString("last_name", "");
    }

    public String getDescription() {
        return sharedPreferences.getString("description", "");
    }

    public String getProfile_image() {
        return sharedPreferences.getString("profile_image", "");
    }

    public String getSocialType() {
        return sharedPreferences.getString("social_type", "");
    }

    public void setProfile_image(String img) {
        editor.putString("profile_image", img);
        editor.apply();
    }

    public void setSocialType(String type) {
        editor.putString("social_type", type);
        editor.apply();
    }

    public String getUserId() {
        return sharedPreferences.getString("userId", "");
    }

    public String getCookie() {
        return sharedPreferences.getString("cookie", "");
    }

    public String getProfession() {
        return sharedPreferences.getString("profession", "");
    }

    public String getProfileImage() {
        return sharedPreferences.getString("profileImage", "");
    }

    public String getEmail() {
        return myprefRemember.getString("email", "");
    }

    public String getPassword() {
        return myprefRemember.getString("password", "");
    }

    public void logout() {
        editor.clear();
        editor.apply();
        editor.commit();
        Intent showLogin = new Intent(context, LoginActivity.class);
        showLogin.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        showLogin.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(showLogin);
        ((Activity) context).finish();
    }

    public String[] getStringPreferenceRem() {
        String arr[] = new String[2];
        String name = myprefRemember.getString(REMEMBER_NAME, "");
        String pwd = myprefRemember.getString(REMEMBER_PWD, "");

        arr[0] = name;
        arr[1] = pwd;
        return arr;
    }

    public void setStringPreferenceRem(String name, String pwd) {
        editorRem.putString(REMEMBER_NAME, name);
        editorRem.putString(REMEMBER_PWD, pwd);
        editorRem.apply();

    }

    public void setDescription(String description) {
        editorRem.putString("description", description);
        editorRem.apply();
    }

    public void setSelected(String filterValue) {
        editor.putString(Filter_id, filterValue);
        editor.apply();
        editor.commit();
    }

    public String getSelected() {
        return sharedPreferences.getString(Filter_id, "");
    }

    public String getAuthToken() {
        return sharedPreferences.getString("authToken", "");
    }

    public boolean isLoggedIn() {
        return sharedPreferences.getBoolean(IS_LOGGEDIN, false);
    }

    @Override
    public Boolean isPreLoggedIn() {
        return sharedPreferences.getBoolean(IS_LOGGEDIN, false);
    }

    @Override
    public UserInfo getUserInfo() {
        UserInfo userInfo = new UserInfo();
        userInfo.userId = sharedPreferences.getString("userId", "");
        userInfo.cookie = sharedPreferences.getString("cookie", "");
        userInfo.first_name = sharedPreferences.getString("first_name", "");
        userInfo.last_name = sharedPreferences.getString("last_name", "");
        userInfo.email = sharedPreferences.getString("email", "");
        userInfo.profile_image = sharedPreferences.getString("profile_image", "");
        userInfo.social_id = sharedPreferences.getString("social_id", "");
        userInfo.description = sharedPreferences.getString("description", "");
        userInfo.isLoggedIn = sharedPreferences.getBoolean(IS_LOGGEDIN,true);
        return userInfo;
    }

    @Override
    public void setUserInfo(UserInfo userInfo) {
        editor.putString("userId", userInfo.userId).apply();
        editor.putString("cookie", userInfo.cookie).apply();
        editor.putString("authToken", userInfo.cookie).apply();
        editor.putString("first_name", userInfo.first_name).apply();
        editor.putString("last_name", userInfo.last_name).apply();
        editor.putString("email", userInfo.email).apply();
        editor.putString("profile_image", userInfo.profile_image).apply();
        editor.putString("social_id", userInfo.social_id).apply();
        editor.putString("description", userInfo.description).apply();
        editor.putBoolean(IS_LOGGEDIN, true).apply();
    }

    @Override
    public HashMap<String, String> getHeader() {
        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put("authToken", sharedPreferences.getString(AUTH_TOKEN, ""));
        return hashMap;
    }

    @Override
    public void logout(Activity activity) {
        myprefRemember.edit().putBoolean(IS_LOGGEDIN, false).apply();
        myprefRemember.edit().clear().apply();
        Intent intent = new Intent(activity, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        activity.startActivity(intent);
        activity.finish();
    }
}
