package com.mindiii.lasross.mycart.model;

import com.android.volley.toolbox.StringRequest;

public class MyCartModel {

    String itemNameVariety;
    String itemName;
    String size;
    String itemPrice;
    String itemKey;
    String quantity;

    public MyCartModel(String itemNameVariety, String itemName, String size, String itemPrice, String itemKey, String quantity) {
        this.itemNameVariety = itemNameVariety;
        this.itemName = itemName;
        this.size = size;
        this.itemPrice = itemPrice;
        this.itemKey = itemKey;
        this.quantity = quantity;
    }

    public String getItemNameVariety() {
        return itemNameVariety;
    }

    public String getItemName() {
        return itemName;
    }

    public String getSize() {
        return size;
    }

    public String getItemPrice() {
        return itemPrice;
    }

    public String getItemKey() {
        return itemKey;
    }

    public String getQuantity() {
        return quantity;
    }
}
