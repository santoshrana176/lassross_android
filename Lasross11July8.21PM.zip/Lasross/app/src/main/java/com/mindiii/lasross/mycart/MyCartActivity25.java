package com.mindiii.lasross.mycart;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.StringRequestListener;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.mindiii.lasross.R;
import com.mindiii.lasross.addtocart.AddToCartLongActivity17;
import com.mindiii.lasross.base.BaseActivity;
import com.mindiii.lasross.home.HomeActivity;
import com.mindiii.lasross.loginregistration.RegistrationActivity;
import com.mindiii.lasross.mycart.adapter.MyCartAdapter;
import com.mindiii.lasross.mycart.interfc.MyCartInterface;
import com.mindiii.lasross.mycart.model.GetCart;
import com.mindiii.lasross.mycart.model.MyCartModel;
import com.mindiii.lasross.mycart.model.UpdateCart;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MyCartActivity25 extends BaseActivity {

    private RecyclerView recyclerView;
    private MyCartAdapter myCartAdapter;
    private List<MyCartModel> modelList;
    private ProgressDialog progressDialog;
    private TextView tvItem, tvTotalAmount, tvDiscount, tvTotal, tvWishList;
    private String itemKey;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.my_cart_activity_layout_25);

        tvItem = findViewById(R.id.tvItem);
        tvTotalAmount = findViewById(R.id.tvTotalAmount);
        tvDiscount = findViewById(R.id.tvDiscount);
        tvTotal = findViewById(R.id.tvTotal);
        tvWishList = findViewById(R.id.tvWishList);

        tvWishList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //startActivity(new Intent(MyCartActivity25.this, HomeActivity.class));
                //finish();
                onBackPressed();
            }
        });

        GsonBuilder gsonBuilder = new GsonBuilder();
        Gson gson = gsonBuilder.create();
        progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        modelList = new ArrayList<>();
        Window window = this.getWindow();
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(this.getResources().getColor(R.color.home_header_bg1));
        myCartApi();
    }

    private void myCartApi() {
        showDilaog(progressDialog);
        progressDialog.setMessage("loading.....");
        getDataManager().getCart(getDataManager().getHeader()).getAsString(new StringRequestListener() {
                    @Override
                    public void onResponse(final String response) {
                        dismissDilaog(progressDialog);
                        GsonBuilder gsonBuilder = new GsonBuilder();
                        final Gson gson = gsonBuilder.create();
                        final GetCart getCart = gson.fromJson(response, GetCart.class);
                        myCartAdapter = new MyCartAdapter(getCart.getItems(), MyCartActivity25.this, new MyCartInterface.ClickListener() {
                            @Override
                            public void onClickListener(int position) throws JSONException {
                                removeCardItemApi(getCart.getItems().get(position).getKey(), getCart, position);
                            }
                            @Override
                            public void onClickPlusMinus(int position, int quantity) {
                                updateCardItemApi(getCart.getItems().get(position).getKey(),
                                                  getCart.getItems().get(position).getProductId(),
                                                  quantity, gson, response);
                            }
                        });

                        int i = myCartAdapter.getItemCount();
                        if(i == 0) {
                            Toast.makeText(MyCartActivity25.this,"No item is present",Toast.LENGTH_LONG).show();
                        }
                        else {
                            recyclerView.setLayoutManager(new LinearLayoutManager(MyCartActivity25.this, LinearLayoutManager.VERTICAL, false));
                            recyclerView.setAdapter(myCartAdapter);
                        }
                    }

                    @Override
                    public void onError(ANError anError) {
                        dismissDilaog(progressDialog);
                    }
                });
    }

    private void removeCardItemApi(final String itemKey, final GetCart getCart, final int position) {
        showDilaog(progressDialog);
        progressDialog.setMessage("loading.....");
        HashMap<String, String> paramas = new HashMap();
        paramas.put("cartId", itemKey);

        getDataManager().doRemoveCartItem(getDataManager().getHeader(),paramas).getAsString(new StringRequestListener() {
            @Override
            public void onResponse(String response) {
                progressDialog.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String status = jsonObject.getString("status");
                    String message = jsonObject.getString("message");
                    getCart.getItems().remove(position);
                    myCartAdapter.notifyItemRemoved(position);
                    Toast.makeText(MyCartActivity25.this,message,Toast.LENGTH_LONG).show();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onError(ANError anError) {
                progressDialog.dismiss();
                if(anError.getErrorCode()==404)
                {
                    Toast.makeText(MyCartActivity25.this,"card id is wrong",Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private void updateCardItemApi(String itemKey, String productId, int quantity, Gson gson, String response) {
        showDilaog(progressDialog);
        progressDialog.setMessage("loading.....");

        final UpdateCart updateCart = gson.fromJson(response, UpdateCart.class);
        final String message  = updateCart.getMessage();
        final String status  = updateCart.getStatus();

        HashMap<String, String> paramas = new HashMap();
        paramas.put("keyId", itemKey);
        paramas.put("productId", productId);
        paramas.put("quantity", quantity+"");
        Log.e("Parameters is ",paramas+"");

        getDataManager().doUpdateCartItem(getDataManager().getHeader(),paramas).getAsString(new StringRequestListener() {
            @Override
            public void onResponse(String response) {
                progressDialog.dismiss();

                if(status.equals("ok")){
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        String message1 = jsonObject.getString("message");
                        Toast.makeText(MyCartActivity25.this,message1,Toast.LENGTH_LONG).show();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onError(ANError anError) {
                progressDialog.dismiss();
                //Log.e("Message is error","Message is error");
            }
        });
    }
}


                    /*{
                        Log.d("HelloWorld","Response: "+response);
                        dismissDilaog(progressDialog);
                        GetCart addCart = gson.fromJson(response, GetCart.class);
                        int itemNumber = addCart.getItemNumber();
                        String totalAmount = addCart.getSubtotal();
                        String discount = addCart.getTax();
                        String total = addCart.getTotal();

                        tvItem.setText(itemNumber+"");
                        tvTotalAmount.setText("£"+totalAmount);
                        tvDiscount.setText(discount+"");
                        tvTotalAmount.setText("£"+total);

                        List<GetCart.ItemsBean> list = new ArrayList<>();
                        list.addAll(addCart.getItems());

                        if(list.size()==0) {
                            toastMessage("No data found");
                        }
                        else {
                            for (int i = 0; i < list.size(); i++) {
                                GetCart.ItemsBean items = list.get(i);
                                GetCart.ItemsBean.VariationBean variation = items.getVariation();
                                itemKey = items.getKey();
                                MyCartModel model = new MyCartModel(items.getCategory(),
                                        items.getPost_title(),
                                        variation.getSize(),
                                        items.getTotal() + "",
                                        itemKey,
                                        Integer.toString(items.getQuantity()));
                                modelList.add(model);

                                myCartAdapter = new MyCartAdapter(modelList, MyCartActivity25.this, new MyCartInterface.ClickListener() {
                                    @Override
                                    public void onClickListener(int position) {
                                       // removeCardItemApi(itemKey);
                                    }

                                    @Override
                                    public void onClickPlusMinus(int position, int quantity) {
                                       // updateCardItemApi(itemKey);
                                    }
                                });
                                recyclerView.setLayoutManager(new LinearLayoutManager(MyCartActivity25.this, LinearLayoutManager.VERTICAL, false));
                                recyclerView.setAdapter(myCartAdapter);
                                modelList = new ArrayList<>();
                                startActivity(new Intent(MyCartActivity25.this, HomeActivity.class));
                            }
                        }
                    }*/