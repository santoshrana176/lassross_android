package com.mindiii.lasross.editprofile.model;

public class UpdateProfile {

    private String status;
    private Object cookie;
    private String cookie_name;
    private User user;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Object getCookie() {
        return cookie;
    }

    public void setCookie(Object cookie) {
        this.cookie = cookie;
    }

    public String getCookie_name() {
        return cookie_name;
    }

    public void setCookie_name(String cookie_name) {
        this.cookie_name = cookie_name;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }


}
