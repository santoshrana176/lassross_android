package com.mindiii.lasross.session_api.prefs.newPrefs;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import com.mindiii.lasross.loginregistration.LoginActivity;
import com.mindiii.lasross.sessionNew.UserInfo;

import java.util.HashMap;

public class AppPrefrencesHelper implements PreferencesHelper{

    private Context context;
    private static SharedPreferences sharedPreferences;
    private static SharedPreferences.Editor editor;

    private static final String IS_LOGGEDIN = "isLoggedIn";

    private static final String AUTH_TOKEN = "authToken";

    private SharedPreferences myprefRemember;

    public AppPrefrencesHelper(Context context) {
        this.context = context;
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        editor = sharedPreferences.edit();
    }


    @Override
    public UserInfo getUserInfo() {

        UserInfo userInfo = new UserInfo();
        userInfo.userId = sharedPreferences.getString("userId", "");
        userInfo.cookie = sharedPreferences.getString("cookie", "");
        userInfo.first_name = sharedPreferences.getString("first_name", "");
        userInfo.last_name = sharedPreferences.getString("last_name", "");
        userInfo.email = sharedPreferences.getString("email", "");
        userInfo.profile_image = sharedPreferences.getString("profile_image", "");
        userInfo.social_id = sharedPreferences.getString("social_id", "");
        userInfo.description = sharedPreferences.getString("description", "");
        userInfo.description = sharedPreferences.getString("facebook", "");
        userInfo.description = sharedPreferences.getString("gmail", "");
        userInfo.isLoggedIn = sharedPreferences.getBoolean(IS_LOGGEDIN,true);

        return userInfo;
    }

    @Override
    public void setUserInfo(UserInfo userInfo) {
        editor.putString("userId", userInfo.userId).apply();
        editor.putString("cookie", userInfo.cookie).apply();
        editor.putString("authToken", userInfo.cookie).apply();
        editor.putString("first_name", userInfo.first_name).apply();
        editor.putString("last_name", userInfo.last_name).apply();
        editor.putString("email", userInfo.email).apply();
        editor.putString("profile_image", userInfo.profile_image).apply();
        editor.putString("social_id", userInfo.social_id).apply();
        editor.putString("description", userInfo.description).apply();
        editor.putString("facebook", userInfo.facebook).apply();
        editor.putString("gmail", userInfo.gmail).apply();
        editor.putBoolean(IS_LOGGEDIN, true).apply();
    }

    @Override
    public HashMap<String, String> getHeader() {
        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put("authToken", sharedPreferences.getString(AUTH_TOKEN, ""));
        return hashMap;
    }


    public String getEmail() {
        return myprefRemember.getString("email", "");
    }

    public String getPassword() {
        return myprefRemember.getString("password", "");
    }

    public void setDescription(String description) {
        editor.putString("description", description);
        editor.apply();
    }

    @Override
    public Boolean isPreLoggedIn() {
        return sharedPreferences.getBoolean(IS_LOGGEDIN, false);
    }

    @Override
    public void logout(Activity activity) {
        myprefRemember.edit().putBoolean(IS_LOGGEDIN, false).apply();
        myprefRemember.edit().clear().apply();
        Intent intent = new Intent(activity, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        activity.startActivity(intent);
        activity.finish();
    }

}
