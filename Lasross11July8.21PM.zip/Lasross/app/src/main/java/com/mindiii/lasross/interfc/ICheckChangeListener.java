package com.mindiii.lasross.interfc;

public interface ICheckChangeListener {
    void onItemChecked(int position, boolean value);
}
