package com.mindiii.lasross.model;

public class RecyclerViewModel {

    String name;

    public RecyclerViewModel(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
