package com.mindiii.lasross.loginregistration.model;

public class SocialLogin{
	private String cookie;
	private User user;
	private String status;
	private String cookieName;

	public void setCookie(String cookie){
		this.cookie = cookie;
	}

	public String getCookie(){
		return cookie;
	}

	public void setUser(User user){
		this.user = user;
	}

	public User getUser(){
		return user;
	}

	public void setStatus(String status){
		this.status = status;
	}

	public String getStatus(){
		return status;
	}

	public void setCookieName(String cookieName){
		this.cookieName = cookieName;
	}

	public String getCookieName(){
		return cookieName;
	}

	@Override
 	public String toString(){
		return 
			"SocialLogin{" + 
			"cookie = '" + cookie + '\'' + 
			",user = '" + user + '\'' + 
			",status = '" + status + '\'' + 
			",cookie_name = '" + cookieName + '\'' + 
			"}";
		}
}
