package com.mindiii.lasross.mycart.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.mindiii.lasross.R;
import com.mindiii.lasross.home.interfc.HeaderInterface;
import com.mindiii.lasross.mycart.interfc.MyCartInterface;
import com.mindiii.lasross.mycart.model.GetCart;
import com.mindiii.lasross.mycart.model.MyCartModel;
import com.squareup.picasso.Picasso;

import org.json.JSONException;

import java.util.List;

public class MyCartAdapter extends RecyclerView.Adapter<MyCartAdapter.Holder> {

    private List<GetCart.ItemsBean> list;
    private Context context;
    MyCartInterface.ClickListener headerInterface;
    private int count;

    public MyCartAdapter(List <GetCart.ItemsBean> list, Context context, MyCartInterface.ClickListener headerInterface ) {
        this.list = list;
        this.context = context;
        this.headerInterface = headerInterface;
        //count = 1;
    }

    @NonNull
    @Override
    public MyCartAdapter.Holder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view;
        MyCartAdapter.Holder holder;

        view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.my_cart_adapter_layout, viewGroup, false);
        holder = new MyCartAdapter.Holder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull final MyCartAdapter.Holder holder, final int i) {

        holder.tvItemNameVariety.setText(list.get(i).getCategory());
        holder.tvItemName.setText(list.get(i).getPost_title());
        holder.tvItemPrice.setText(list.get(i).getTotal());
        holder.tvItemSize.setText("23");
        holder.tvQuantity.setText(list.get(i).getQuantity());
        count = Integer.parseInt(list.get(i).getQuantity());
        Picasso.with(context)
                .load(list.get(i).getFeaturedImage())
                .resize(500, 600)
                .into(holder.ivImage);

        holder.tvMinus.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {
                if (count <= 1)
                    Toast.makeText(context,"quantity should not be less than 1",Toast.LENGTH_LONG).show();
                    //toastMessage("quantity should not be less than 1");
                else {
                    count--;
                    holder.tvQuantity.setText("" + count);
                    headerInterface.onClickPlusMinus(i,count);
                }
            }
        });

        holder.tvPlus.setOnClickListener(new View.OnClickListener() {
            //@SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {
                count++;
                holder.tvQuantity.setText("" + count);
                headerInterface.onClickPlusMinus(i,count);
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class Holder extends RecyclerView.ViewHolder implements View.OnClickListener {

        private ImageView ivImage, ivDelete;
        private TextView tvItemNameVariety, tvItemName, tvItemSize, tvItemPrice, tvPlus, tvQuantity, tvMinus;

        public Holder(@NonNull View itemView) {
            super(itemView);
            ivImage = itemView.findViewById(R.id.ivImage);
            ivDelete = itemView.findViewById(R.id.ivDelete);
            tvItemNameVariety = itemView.findViewById(R.id.tvItemNameVariety);
            tvItemName = itemView.findViewById(R.id.tvItemName);
            tvItemPrice = itemView.findViewById(R.id.tvItemPrice);
            tvItemSize = itemView.findViewById(R.id.tvItemSize);
            tvItemPrice = itemView.findViewById(R.id.tvItemPrice);
            tvPlus = itemView.findViewById(R.id.tvPlus);
            tvQuantity = itemView.findViewById(R.id.tvQuantity);
            tvMinus = itemView.findViewById(R.id.tvMinus);

            ivDelete.setOnClickListener(this);
            tvMinus.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            switch (view.getId()){
                case R.id.ivDelete:
                    try {
                        headerInterface.onClickListener(getAdapterPosition());
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    break;
            }

        }
    }
}



