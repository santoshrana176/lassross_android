package com.mindiii.lasross.addtocart.model;

public class SizeModel {

    private String size;
    private boolean isChecked;

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public boolean isChecked() {
        return isChecked;
    }

    public void setChecked(boolean checked) {
        isChecked = checked;
    }
}
