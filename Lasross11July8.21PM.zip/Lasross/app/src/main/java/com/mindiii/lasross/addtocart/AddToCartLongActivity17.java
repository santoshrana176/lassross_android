package com.mindiii.lasross.addtocart;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;

import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.StringRequestListener;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.mindiii.lasross.R;
import com.mindiii.lasross.addtocart.adapter.DescriptionAdapter;
import com.mindiii.lasross.addtocart.adapter.RelatedProductAdapter;
import com.mindiii.lasross.adapter.ViewPagerAdapter;
import com.mindiii.lasross.addtocart.adapter.SizeAdapter;
import com.mindiii.lasross.addtocart.interfc.RelatedProductInterface;
import com.mindiii.lasross.addtocart.model.AddCart;
import com.mindiii.lasross.addtocart.model.AvailableColor;
import com.mindiii.lasross.addtocart.model.DescriptionModel;
import com.mindiii.lasross.addtocart.model.Product;
import com.mindiii.lasross.addtocart.model.ProductDetail;
import com.mindiii.lasross.addtocart.model.RelatedProducts;
import com.mindiii.lasross.addtocart.model.SizeModel;
import com.mindiii.lasross.addtocart.model.SizeModel1;
import com.mindiii.lasross.addtocart.model.Tags;
import com.mindiii.lasross.base.BaseActivity;
import com.mindiii.lasross.home.HomeActivity;
import com.mindiii.lasross.mycart.MyCartActivity25;
import com.mindiii.lasross.sessionNew.Session;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;

public class AddToCartLongActivity17 extends BaseActivity {

    private int count, count1;
    private TextView tvItemNameVariety;
    private TextView tvItemName;
    private TextView tvItemPrice;
    private ImageView ivCancel;
    private TextView tvQuantity, tvQuantity1, tvMoveToBag;
    //private int[] layouts = {R.layout.swipe_layout_1, R.layout.swipe_layout_2, R.layout.swipe_layout_3};
    private LinearLayout dotLayout, addToCartFullLayout, llColorAvailable, llNoOfItem1, llNoOfItem, llItemAndColor, llSize;
    private Gson gson;
    private ProgressDialog progressDialog;
    private RecyclerView rvRecycler;
    private RecyclerView rvRecyclerDescription;
    //private RecyclerView rvRecyclerSize;
    //private RecyclerView rvRecyclerColor;
    private RelatedProductAdapter relatedProductAdapter;
    private DescriptionAdapter descriptionAdapter;
    private SizeAdapter sizeAdapter;
    private List<DescriptionModel.HeaderListModel> headerList;
    private List<DescriptionModel> descriptionList;
    private List<SizeModel> sizeList, colorList;
    private String strItemSize, size="", color="";
    private Spinner spinnerSize, spinnerColor;
    private List<String> sizeSpinnerList, colorSpinnerList;
    private ViewPager viewPager;
    private String []strArray;
    private Iterator keys;
    private List<String> currentKeyList, currentKeyColor;
    private List<SizeModel1> keyList;
    private ArrayList<SizeModel1> sizeList1;
    private SizeModel1 sizeModel1 = null;
    private String variationId;
    private String productType;

    @SuppressLint({"CutPasteId", "SetTextI18n"})
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_to_cart_long_activity_layout_17);
        count = 1;
        count1 = 1;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            Window w = getWindow();
            w.setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        }

        GsonBuilder gsonBuilder = new GsonBuilder();
        gson = gsonBuilder.create();

        currentKeyList = new ArrayList<>();
        currentKeyColor = new ArrayList<>();
        keyList = new ArrayList<>();
        sizeList1 = new ArrayList<>();

        rvRecycler = findViewById(R.id.rvRecycler);
        rvRecyclerDescription = findViewById(R.id.rvRecyclerDescription);
        /*rvRecyclerColor = findViewById(R.id.rvRecyclerColor);
          rvRecyclerSize = findViewById(R.id.rvRecyclerSize);*/
        LinearLayout llAddToCart = findViewById(R.id.llAddToCart);

        Session session = new Session(this);
        viewPager = findViewById(R.id.viewPager);

        TextView tvStartNo = findViewById(R.id.tvStartNo);
        tvItemNameVariety = findViewById(R.id.tvItemNameVariety);
        tvItemName = findViewById(R.id.tvItemName);
        tvItemPrice = findViewById(R.id.tvItemPrice);
        TextView tvMinus = findViewById(R.id.tvMinus);
        TextView tvPlus = findViewById(R.id.tvPlus);
        TextView tvMinus1 = findViewById(R.id.tvMinus1);
        TextView tvPlus1 = findViewById(R.id.tvPlus1);
        tvQuantity = findViewById(R.id.tvQuantity);
        tvQuantity1 = findViewById(R.id.tvQuantity1);
        tvMoveToBag = findViewById(R.id.tvMoveToBag);

        ivCancel = findViewById(R.id.ivCancel);

        ivCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(AddToCartLongActivity17.this, HomeActivity.class));
            }
        });

        dotLayout = findViewById(R.id.dotLayout);
        addToCartFullLayout = findViewById(R.id.addToCartFullLayout);
        llColorAvailable = findViewById(R.id.llColorAvailable);
        llNoOfItem1 = findViewById(R.id.llNoOfItem1);
        llNoOfItem = findViewById(R.id.llNoOfItem);
        llItemAndColor = findViewById(R.id.llItemAndColor);
        llSize = findViewById(R.id.llSize);

        spinnerSize = findViewById(R.id.spinnerSize);
        spinnerColor = findViewById(R.id.spinnerColor);

        sizeSpinnerList = new ArrayList<>();
        colorSpinnerList = new ArrayList<>();

        tvMinus.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {
                if (count <= 1)
                    toastMessage("quantity should not be less than 1");
                else {
                    count--;
                    tvQuantity.setText("" + count);
                }
            }
        });

        tvPlus.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {
                count++;
                tvQuantity.setText("" + count);
            }
        });

        tvMinus1.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {
                if (count1 <= 1)
                    toastMessage("quantity should not be less than 1");
                else {
                    count1--;
                    tvQuantity1.setText("" + count1);
                }
            }
        });

        tvPlus1.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {
                count1++;
                tvQuantity1.setText("" + count1);
            }
        });

        progressDialog = new ProgressDialog(this);

        ///////////////////PRODUCT DETAIL API METHOD/////////////////////
        final String id = getIntent().getStringExtra("id");
        ////////////////////////////////////////////////////////////////

        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int i, float v, int i1) {
            }

            @Override
            public void onPageSelected(int i) {
                createDots(i,strArray);
            }

            @Override
            public void onPageScrollStateChanged(int i) {
            }
        });

        //////////////////////////////////////////////////////////////////////////////////

        productDetailApi(id);

        llAddToCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addToCartApi(id);
            }
        });

        /*///////////////////COLOR RECYCLER VIEW///////////////////////////
        List<ColorModel> colorList = new ArrayList<>();
        for (int i = 1; i <= 5; i++) {
            ColorModel itemList = new ColorModel(Color.parseColor("#bdbdbd"));
            colorList.add(itemList);
        }
        ColorAdapter colorAdapter = new ColorAdapter(colorList, this);
        rvRecyclerColor.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        rvRecyclerColor.setAdapter(colorAdapter);
        ////////////////////////////////////////////////////////////////*/

        ImageView ivBackground = findViewById(R.id.ivBackground);
        Picasso.with(this)
                .load(R.drawable.splash_bg)
                .resize(1000, 600)
                .into(ivBackground);

        tvStartNo.setText("(" + 30 + ")");

       /* ViewPagerAdapter viewPagerAdapter = new ViewPagerAdapter(images, this);
        viewPager.setAdapter(viewPagerAdapter);*/
       //addToMyCart();
    }


    @SuppressLint("SetTextI18n")
    private void openDialog(Product product) {
        final Dialog dialog = new Dialog(AddToCartLongActivity17.this);//,android.R.style.Theme_Dialog);
        dialog.setContentView(R.layout.dialog_artboard_18);
        Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        ImageView ivCancel;
        TextView tvShortDescription, tvWeightDimension, tvSKU, tvCategory, tvTag;
        ivCancel = dialog.findViewById(R.id.ivCancel);
        tvShortDescription = dialog.findViewById(R.id.tvShortDescription);
        tvWeightDimension = dialog.findViewById(R.id.tvWeightDimension);
        tvSKU = dialog.findViewById(R.id.tvSKU);
        tvCategory = dialog.findViewById(R.id.tvCategory);
        tvTag = dialog.findViewById(R.id.tvTag);

        ivCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });

        tvShortDescription.setText(product.getShortDescription());
        tvWeightDimension.setText("The weight is "+product.getWeight()+" kg with dimension of "+product.getLength()+"*"+product.getWidth()+"*"+product.getHeight()+" cm");
        tvSKU.setText(product.getSku());
        tvCategory.setText(product.getCategory());
        List<Tags> list = product.getTags();
        String s="";

        for (int i = 0; list.size() > i; i++)
        {
            Tags tags = list.get(i);
            s =  tags.getName();
        }

        tvTag.setText(s);

        dialog.setTitle("Add Photo!");
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(dialog.getWindow().getAttributes());
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        lp.windowAnimations = R.style.DialogAnimation;
        dialog.getWindow().setAttributes(lp);
        dialog.show();
    }

    private void addToCartApi(String id) {
        progressDialog.show();
        progressDialog.setMessage("loading.....");
        final HashMap<String, String> paramas = new HashMap();
        paramas.put("productId", id);



        paramas.put("quantity", Integer.toString(count));

        if(productType.equals("simple"))
        {
            paramas.put("variation_id", id);
            paramas.put("color", "");
            paramas.put("size", "");
        }
        else if(productType.equals("variable")){
            paramas.put("variation_id", variationId);
            paramas.put("color", color);
            paramas.put("size", size);
        }

        Log.e("parems are ",paramas+"");

        getDataManager().doAddToCart(getDataManager().getHeader(), paramas)
                .getAsString(new StringRequestListener() {
                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();
                        AddCart addCart = gson.fromJson(response, AddCart.class);
                        addToCartConfirmAlertBox(addCart.getMessage());
                    }
                    @Override
                    public void onError(ANError anError) {
                        progressDialog.dismiss();
                        Toast.makeText(AddToCartLongActivity17.this, "product id is required", Toast.LENGTH_LONG).show();
                        if (anError.getErrorCode() == 404) {
                            toastMessage("productId is required");
                        }
                    }
                });
    }

    private void descriptionRecyclerView(String description, String content, String image) {
        descriptionList = new ArrayList<>();
        for (int i = 1; i <= 5; i++) {
            DescriptionModel itemList = new DescriptionModel(description, content, image);
            descriptionList.add(itemList);
        }
        descriptionAdapter = new DescriptionAdapter(descriptionList, this);
        rvRecyclerDescription.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        rvRecyclerDescription.setAdapter(descriptionAdapter);
    }

    private void productDetailApi(final String id) {

        progressDialog.show();
        progressDialog.setMessage("loading.....");

        final HashMap<String, String> paramas = new HashMap();
        paramas.put("productId", id);

        getDataManager().getProductDetail(getDataManager().getHeader(), paramas)
                .getAsString(new StringRequestListener() {
                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();
                        try {
                            JSONObject object = new JSONObject(response);
                            JSONObject product = object.getJSONObject("product");
                            JSONObject availableSize = product.getJSONObject("availableSize");
                            String currentDynamicKey="";
                                keys = availableSize.keys();
                                while(keys.hasNext()) {
                                    currentDynamicKey = (String) keys.next();

                                    JSONArray jsonArray = availableSize.getJSONArray(currentDynamicKey);
                                    sizeModel1 = new SizeModel1();
                                    for (int i = 0; i < jsonArray.length(); i++) {

                                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                                        sizeModel1.setKeyName(currentDynamicKey);
                                        currentKeyList.add(sizeModel1.getKeyName());
                                        //currentKeyColor.add(s)
                                        sizeModel1.setVariation_id(jsonObject.getString("variation_id"));
                                        sizeModel1.setColor(jsonObject.getString("color"));
                                        sizeList1.add(sizeModel1);
                                    }
                                }

                                /**-----------*/
                            spinnerSize.setAdapter(new ArrayAdapter<String>(
                                    AddToCartLongActivity17.this,
                                    android.R.layout.simple_spinner_dropdown_item, currentKeyList));
                            spinnerSize.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                @Override
                                public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                                    size = spinnerSize.getItemAtPosition(spinnerSize.getSelectedItemPosition()).toString();
                                    currentKeyColor.clear();
                                    for(SizeModel1 s: sizeList1) {
                                        if (size.equals(s.getKeyName()))
                                            currentKeyColor.add(s.getColor());
                                    }

                                    spinnerColor.setAdapter(new ArrayAdapter<String>(
                                            AddToCartLongActivity17.this,
                                            android.R.layout.simple_spinner_dropdown_item, currentKeyColor));

                                    spinnerColor.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                        @Override
                                        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                                            color = spinnerColor.getItemAtPosition(spinnerColor.getSelectedItemPosition()).toString();
                                            for(SizeModel1 s: sizeList1)
                                            {
                                                if(color.equals(s.getColor()))
                                                variationId = s.getVariation_id();
                                            }
                                            // Toast.makeText(getApplicationContext(),color,Toast.LENGTH_LONG).show();
                                        }

                                        @Override
                                        public void onNothingSelected(AdapterView<?> adapterView) {
                                            // DO Nothing here
                                        }
                                    });
                                }

                                @Override
                                public void onNothingSelected(AdapterView<?> adapterView) {
                                }
                            });
                            /*spinnerColor.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                @Override
                                public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                                    color = spinnerColor.getItemAtPosition(spinnerColor.getSelectedItemPosition()).toString();
                                    // Toast.makeText(getApplicationContext(),color,Toast.LENGTH_LONG).show();
                                }

                                @Override
                                public void onNothingSelected(AdapterView<?> adapterView) {
                                    // DO Nothing here
                                }
                            });*/

                                /**----------*/

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        ProductDetail productDetail = gson.fromJson(response,ProductDetail.class);
                        final Product product = productDetail.getProduct();
                        productType = product.getProduct_type();
                        List<String> galleryImage = product.getGalleryImage();

                        tvMoveToBag.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                openDialog(product);
                            }
                        });

                        String[] array = galleryImage.toArray(new String[0]);
                        createDots(0, array);
                        System.out.println(Arrays.toString(array));

                        for (String s:array) {
                            String[] images = new String[]{s};
                            ViewPagerAdapter viewPagerAdapter = new ViewPagerAdapter(images, AddToCartLongActivity17.this);
                            viewPager.setAdapter(viewPagerAdapter);
                        }

                        /*if(product_type.equals("variable")) {
                            addToCartFullLayout.setVisibility(View.GONE);
                            llSize.setVisibility(View.GONE);
                            llColorAvailable.setVisibility(View.GONE);
                            llNoOfItem.setVisibility(View.GONE);
                            llNoOfItem1.setVisibility(View.VISIBLE);
                        }
                        else {
                            addToCartFullLayout.setVisibility(View.VISIBLE);
                            llSize.setVisibility(View.GONE);
                            llColorAvailable.setVisibility(View.GONE);
                            llNoOfItem.setVisibility(View.GONE);
                            llNoOfItem1.setVisibility(View.VISIBLE);
                        }*/



                        ////////////////////Size///////////////////////
                        /*String sizeItem = product.getSize();
                        final String[] itemSize = sizeItem.split(",");
                        sizeList = new ArrayList<>();
                        sizeList.clear();
                        for (String s : itemSize) {
                            SizeModel sizeModel = new SizeModel();
                            sizeModel.setSize(s);
                            sizeList.add(sizeModel);
                            sizeSpinnerList.add(s);
                        }
                        spinnerSize.setAdapter(new ArrayAdapter<String>(AddToCartLongActivity17.this, android.R.layout.simple_spinner_dropdown_item, sizeSpinnerList));
                        */

                        //////////////////////////////////////////////



                        //////////////////Color///////////////////////
                        /*spinnerColor.setAdapter(new ArrayAdapter<String>(
                                AddToCartLongActivity17.this,
                                android.R.layout.simple_spinner_dropdown_item, currentKeyColor));*/
                        /*String colorItem = product.getColor();
                        final String[] itemColor = colorItem.split(",");
                        colorList = new ArrayList<>();
                        colorList.clear();
                        for (String s : itemColor) {
                            SizeModel sizeModel = new SizeModel();
                            sizeModel.setSize(s);
                            colorList.add(sizeModel);
                            colorSpinnerList.add(s);
                        }
                        spinnerColor.setAdapter(new ArrayAdapter<String>(AddToCartLongActivity17.this, android.R.layout.simple_spinner_dropdown_item, colorSpinnerList));
                        */
                        /////////////////////////////////////////////


                        /*if(colorItem.length()==0)
                        {
                            llNoOfItem1.setVisibility(View.VISIBLE);
                            //llItemAndColor.setVisibility(View.GONE);
                            llNoOfItem.setVisibility(View.GONE);
                            llColorAvailable.setVisibility(View.GONE);
                        }
                        else
                        {
                            llNoOfItem1.setVisibility(View.GONE);
                            //llItemAndColor.setVisibility(View.VISIBLE);
                            llNoOfItem.setVisibility(View.VISIBLE);
                            llColorAvailable.setVisibility(View.VISIBLE);
                        }


                        if(sizeItem.length()==0)
                        {
                            llSize.setVisibility(View.GONE);
                        }
                        else
                        {
                            llSize.setVisibility(View.VISIBLE);
                        }*/


                        tvItemNameVariety.setText(product.getCategory());
                        tvItemName.setText(product.getPostTitle());
                        tvItemPrice.setText(product.getPrice());

                        List<RelatedProducts> list = new ArrayList<>(product.getRelatedProducts());

                        headerList = new ArrayList<>();
                        descriptionList = new ArrayList<>();

                        for (int i = 0; i < list.size(); i++) {
                            RelatedProducts relatedProducts = list.get(i);
                            //upperRecyclerView(relatedProducts.getCategory(), relatedProducts.getPost_title(),relatedProducts.getPrice(), relatedProducts.getFeaturedImage(), list.size());
                            DescriptionModel.HeaderListModel itemList = new DescriptionModel.HeaderListModel
                                    (relatedProducts.getCategory(),
                                    relatedProducts.getPost_title(),
                                    relatedProducts.getPrice(),
                                    relatedProducts.getFeaturedImage(),
                                    Integer.toString(relatedProducts.getID()));
                            headerList.add(itemList);
                            relatedProductAdapter = new RelatedProductAdapter(headerList, AddToCartLongActivity17.this, new RelatedProductInterface() {
                                @Override
                                public void onClickListener( int position) {
                                    String id;
                                    id = headerList.get(position).getId();

                                    //Toast.makeText(AddToCartLongActivity17.this,"AddToCArtActivity 17 is working",Toast.LENGTH_LONG).show();
                                    Intent intent = new Intent(new Intent(AddToCartLongActivity17.this, AddToCartLongActivity17.class));
                                    intent.putExtra("id", id);
                                    startActivity(intent);//startActivity(new Intent(AddToCartLongActivity17.this, AddToCartLongActivity17.class));
                                }
                            });
                            rvRecycler.setLayoutManager(new LinearLayoutManager(AddToCartLongActivity17.this, LinearLayoutManager.HORIZONTAL, false));
                            rvRecycler.setAdapter(relatedProductAdapter);

                            //descriptionRecyclerView(relatedProducts.getShort_description(), relatedProducts.getPost_content(), relatedProducts.getFeaturedImage());
                            DescriptionModel description = new DescriptionModel(relatedProducts.getShort_description(), relatedProducts.getPost_content(), relatedProducts.getFeaturedImage());
                            descriptionList.add(description);
                            descriptionAdapter = new DescriptionAdapter(descriptionList, AddToCartLongActivity17.this);
                            rvRecyclerDescription.setLayoutManager(new LinearLayoutManager(AddToCartLongActivity17.this, LinearLayoutManager.HORIZONTAL, false));
                            rvRecyclerDescription.setAdapter(descriptionAdapter);
                        }
                    }

                    @Override
                    public void onError(ANError anError) {
                        progressDialog.dismiss();
                    }
                });
    }

    private void createDots(int position, String[] array) {
        if (dotLayout != null)
            dotLayout.removeAllViews();
        ImageView[] ivRhombus = new ImageView[array.length];
        for (int i = 0; i < array.length; i++) {
            ivRhombus[i] = new ImageView(this);
            if (i == position) {
                ivRhombus[i].setImageDrawable(ContextCompat.getDrawable(this, R.drawable.rhombus_filled_shape));
            } else {
                ivRhombus[i].setImageDrawable(ContextCompat.getDrawable(this, R.drawable.rhombus_unfilled_shape));
            }
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(30, 30);
            params.setMargins(6, 0, 6, 0);
            dotLayout.addView(ivRhombus[i], params);
        }
    }

    private void addToCartConfirmAlertBox(String message) {
        final Dialog dialog = new Dialog(AddToCartLongActivity17.this);//,android.R.style.Theme_Dialog);
        dialog.setContentView(R.layout.add_to_cart_confirm_dialog);
        Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        TextView tvMessage, tvOK;
        tvMessage = dialog.findViewById(R.id.tvMessage);
        tvOK = dialog.findViewById(R.id.tvOK);

        ivCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });

        tvMessage.setText(message);
        tvOK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(AddToCartLongActivity17.this, MyCartActivity25.class));
                dialog.dismiss();
            }
        });

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(dialog.getWindow().getAttributes());
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        lp.windowAnimations = R.style.DialogAnimation;
        dialog.getWindow().setAttributes(lp);
        dialog.show();

    }
}




