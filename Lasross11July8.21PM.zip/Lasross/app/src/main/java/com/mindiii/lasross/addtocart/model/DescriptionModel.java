package com.mindiii.lasross.addtocart.model;

public class DescriptionModel {

    private String header;
    private String detail;
    private String picURL;

    public DescriptionModel(String header, String detail, String picURL) {
        this.header = header;
        this.detail = detail;
        this.picURL = picURL;
    }

    public String getHeader() {
        return header;
    }

    public String getDetail() {
        return detail;
    }

    public String getPicURL() {
        return picURL;
    }


    public static class HeaderListModel {

        String itemNameVariety;
        String itemName;
        String itemPrice;
        String picURL;
        String id;

        public HeaderListModel(String itemNameVariety, String itemName, String itemPrice, String picURL, String id) {
            this.itemNameVariety = itemNameVariety;
            this.itemName = itemName;
            this.itemPrice = itemPrice;
            this.picURL = picURL;
            this.id = id;
        }

        public String getItemNameVariety() {
            return itemNameVariety;
        }

        public String getItemName() {
            return itemName;
        }

        public String getItemPrice() {
            return itemPrice;
        }

        public String getPicURL() {
            return picURL;
        }

        public String getId() {
            return id;
        }
    }
}
