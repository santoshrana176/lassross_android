package com.mindiii.lasross.session_api.prefs;

import com.mindiii.lasross.session_api.prefs.newPrefs.PreferencesHelper;
import com.mindiii.lasross.session_api.prefs.remote.ApiHelper;

public interface DataManager extends PreferencesHelper, ApiHelper {

}
