package com.mindiii.lasross.session_api.prefs.newPrefs;

import android.app.Activity;

import com.mindiii.lasross.sessionNew.UserInfo;

import java.util.HashMap;

public interface PreferencesHelper {

    Boolean isPreLoggedIn();

    UserInfo getUserInfo();

    void setUserInfo(UserInfo userInfo);

    HashMap<String, String> getHeader();

    void logout(Activity activity);
}
