package com.mindiii.lasross.home.interfc;

public interface HeaderInterface {
    void onClickListener(int position);
}
