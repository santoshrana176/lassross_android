package com.mindiii.lasross.addtocart.model;

import java.util.ArrayList;
import java.util.List;

public class Product{
    private String post_title;
    private String short_description;
    private boolean featured;
    private boolean virtual;
    private int menuOrder;
    private String color;
    private String taxStatus;
    private String description;
    private int discount;
    private int reviewCount;
    private String catalogVisibility;
    private List<Object> getRelated;
    private List<RelatedProducts> related_products;
    private String regularPrice;
    private boolean reviewsAllowed;
    private String price;
    private String postType;
    private int iD;
    private String sku;
    private int totalSales;
    private String slug;
    private Object dateOnSaleFrom;
    private String height;
    private boolean manageStock;
    private String stockStatus;
    private String purchaseNote;
    private String currencySymbol;
    private DateCreated dateCreated;
    private String taxClass;
    private String length;
    private String weight;
    private String averageRating;
    private Object stockQuantity;
    private String salePrice;
    private List<Tags> tags;
    private Object dateOnSaleTo;
    private boolean soldIndividually;
    private DateModified dateModified;
    private String size;
    private String backorders;
    private String featuredImage;
    private String width;
    private List<Object> ratingCounts;
    private String status;
    private String dimensions;
    private String category;
    private List<String> categoryAll;
    private String product_type;
    private List<String> galleryImage;
    private List<String> get_related;
    //private AvailableColor availableColor;
    //private AvailableSize availableSize;

    public String getProduct_type() {
        return product_type;
    }

    public void setProduct_type(String product_type) {
        this.product_type = product_type;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public List<String> getCategoryAll() {
        return categoryAll;
    }

    public void setCategoryAll(List<String> categoryAll) {
        this.categoryAll = categoryAll;
    }

    public void setPostTitle(String postTitle){
        this.post_title = postTitle;
    }

    public String getPostTitle(){
        return post_title;
    }

    public void setShortDescription(String shortDescription){
        this.short_description = shortDescription;
    }

    public String getShortDescription(){
        return short_description;
    }

    public void setFeatured(boolean featured){
        this.featured = featured;
    }

    public boolean isFeatured(){
        return featured;
    }

    public void setVirtual(boolean virtual){
        this.virtual = virtual;
    }

    public boolean isVirtual(){
        return virtual;
    }

    public void setMenuOrder(int menuOrder){
        this.menuOrder = menuOrder;
    }

    public int getMenuOrder(){
        return menuOrder;
    }

    public void setColor(String color){
        this.color = color;
    }

    public String getColor(){
        return color;
    }

    public void setTaxStatus(String taxStatus){
        this.taxStatus = taxStatus;
    }

    public String getTaxStatus(){
        return taxStatus;
    }

    public void setDescription(String description){
        this.description = description;
    }

    public String getDescription(){
        return description;
    }

    public void setDiscount(int discount){
        this.discount = discount;
    }

    public int getDiscount(){
        return discount;
    }

    public void setReviewCount(int reviewCount){
        this.reviewCount = reviewCount;
    }

    public int getReviewCount(){
        return reviewCount;
    }

    public void setCatalogVisibility(String catalogVisibility){
        this.catalogVisibility = catalogVisibility;
    }

    public String getCatalogVisibility(){
        return catalogVisibility;
    }

    public void setGetRelated(List<Object> getRelated){
        this.getRelated = getRelated;
    }

    public List<Object> getGetRelated(){
        return getRelated;
    }

    public void setRelatedProducts(List<RelatedProducts> relatedProducts){
        this.related_products = relatedProducts;
    }

    public List<RelatedProducts> getRelatedProducts(){
        return related_products;
    }

    public void setRegularPrice(String regularPrice){
        this.regularPrice = regularPrice;
    }

    public String getRegularPrice(){
        return regularPrice;
    }

    public void setReviewsAllowed(boolean reviewsAllowed){
        this.reviewsAllowed = reviewsAllowed;
    }

    public boolean isReviewsAllowed(){
        return reviewsAllowed;
    }

    public void setPrice(String price){
        this.price = price;
    }

    public String getPrice(){
        return price;
    }

    public void setPostType(String postType){
        this.postType = postType;
    }

    public String getPostType(){
        return postType;
    }

    public void setID(int iD){
        this.iD = iD;
    }

    public int getID(){
        return iD;
    }

    public void setSku(String sku){
        this.sku = sku;
    }

    public String getSku(){
        return sku;
    }

    public void setTotalSales(int totalSales){
        this.totalSales = totalSales;
    }

    public int getTotalSales(){
        return totalSales;
    }

    public void setSlug(String slug){
        this.slug = slug;
    }

    public String getSlug(){
        return slug;
    }

    public void setDateOnSaleFrom(Object dateOnSaleFrom){
        this.dateOnSaleFrom = dateOnSaleFrom;
    }

    public Object getDateOnSaleFrom(){
        return dateOnSaleFrom;
    }

    public void setHeight(String height){
        this.height = height;
    }

    public String getHeight(){
        return height;
    }

    public void setManageStock(boolean manageStock){
        this.manageStock = manageStock;
    }

    public boolean isManageStock(){
        return manageStock;
    }

    public void setStockStatus(String stockStatus){
        this.stockStatus = stockStatus;
    }

    public String getStockStatus(){
        return stockStatus;
    }

    public void setPurchaseNote(String purchaseNote){
        this.purchaseNote = purchaseNote;
    }

    public String getPurchaseNote(){
        return purchaseNote;
    }

    public void setCurrencySymbol(String currencySymbol){
        this.currencySymbol = currencySymbol;
    }

    public String getCurrencySymbol(){
        return currencySymbol;
    }

    public void setDateCreated(DateCreated dateCreated){
        this.dateCreated = dateCreated;
    }

    public DateCreated getDateCreated(){
        return dateCreated;
    }

    public void setTaxClass(String taxClass){
        this.taxClass = taxClass;
    }

    public String getTaxClass(){
        return taxClass;
    }

    public void setLength(String length){
        this.length = length;
    }

    public String getLength(){
        return length;
    }

    public void setWeight(String weight){
        this.weight = weight;
    }

    public String getWeight(){
        return weight;
    }

    public void setAverageRating(String averageRating){
        this.averageRating = averageRating;
    }

    public String getAverageRating(){
        return averageRating;
    }

    public void setStockQuantity(Object stockQuantity){
        this.stockQuantity = stockQuantity;
    }

    public Object getStockQuantity(){
        return stockQuantity;
    }

    public void setSalePrice(String salePrice){
        this.salePrice = salePrice;
    }

    public String getSalePrice(){
        return salePrice;
    }

    public void setTags(List<Tags> tags){
        this.tags = tags;
    }

    public List<Tags> getTags(){
        return tags;
    }

    public void setDateOnSaleTo(Object dateOnSaleTo){
        this.dateOnSaleTo = dateOnSaleTo;
    }

    public Object getDateOnSaleTo(){
        return dateOnSaleTo;
    }

    public void setSoldIndividually(boolean soldIndividually){
        this.soldIndividually = soldIndividually;
    }

    public boolean isSoldIndividually(){
        return soldIndividually;
    }

    public void setDateModified(DateModified dateModified){
        this.dateModified = dateModified;
    }

    public DateModified getDateModified(){
        return dateModified;
    }

    public void setSize(String size){
        this.size = size;
    }

    public String getSize(){
        return size;
    }

    public void setBackorders(String backorders){
        this.backorders = backorders;
    }

    public String getBackorders(){
        return backorders;
    }

    public void setFeaturedImage(String featuredImage){
        this.featuredImage = featuredImage;
    }

    public String getFeaturedImage(){
        return featuredImage;
    }

    public void setWidth(String width){
        this.width = width;
    }

    public String getWidth(){
        return width;
    }

    public void setRatingCounts(List<Object> ratingCounts){
        this.ratingCounts = ratingCounts;
    }

    public List<Object> getRatingCounts(){
        return ratingCounts;
    }

    public void setStatus(String status){
        this.status = status;
    }

    public String getStatus(){
        return status;
    }

    public void setDimensions(String dimensions){
        this.dimensions = dimensions;
    }

    public String getDimensions(){
        return dimensions;
    }

    public List<String> getGalleryImage() {
        return galleryImage;
    }

    public void setGalleryImage(List<String> galleryImage) {
        this.galleryImage = galleryImage;
    }

    public List<String> getGet_related() {
        return get_related;
    }

    public void setGet_related(List<String> get_related) {
        this.get_related = get_related;
    }

    /*public AvailableColor getAvailableColor() {
        return availableColor;
    }

    public void setAvailableColor(AvailableColor availableColor) {
        this.availableColor = availableColor;
    }

    public AvailableSize getAvailableSize() {
        return availableSize;
    }

    public void setAvailableSize(AvailableSize availableSize) {
        this.availableSize = availableSize;
    }*/
}