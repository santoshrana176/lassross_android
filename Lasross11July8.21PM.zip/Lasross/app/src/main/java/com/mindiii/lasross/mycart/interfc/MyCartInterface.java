package com.mindiii.lasross.mycart.interfc;

import org.json.JSONException;

public interface MyCartInterface {

    interface ClickListener {
        void onClickListener(int position) throws JSONException;
        void onClickPlusMinus(int position, int quantity);
    }

}
