package com.mindiii.lasross.loginregistration.model;

public class Capabilities{
	private boolean customer;

	public void setCustomer(boolean customer){
		this.customer = customer;
	}

	public boolean isCustomer(){
		return customer;
	}

	@Override
 	public String toString(){
		return 
			"Capabilities{" + 
			"customer = '" + customer + '\'' + 
			"}";
		}
}
