package com.mindiii.lasross.addtocart.model;

import java.io.Serializable;
import java.util.List;

public class  AddCart implements Serializable {

    private String status;
    private com.mindiii.lasross.addtocart.model.AddCart.CartBean cart;
    private String message;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public com.mindiii.lasross.addtocart.model.AddCart.CartBean getCart() {
        return cart;
    }

    public void setCart(com.mindiii.lasross.addtocart.model.AddCart.CartBean cart) {
        this.cart = cart;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public static class CartBean {
        private int itemNumber;
        private String subtotal;
        private String tax;
        private String total;
        private List<com.mindiii.lasross.addtocart.model.AddCart.CartBean.ItemsBean> items;

        public int getItemNumber() {
            return itemNumber;
        }

        public void setItemNumber(int itemNumber) {
            this.itemNumber = itemNumber;
        }

        public String getSubtotal() {
            return subtotal;
        }

        public void setSubtotal(String subtotal) {
            this.subtotal = subtotal;
        }

        public String getTax() {
            return tax;
        }

        public void setTax(String tax) {
            this.tax = tax;
        }

        public String getTotal() {
            return total;
        }

        public void setTotal(String total) {
            this.total = total;
        }

        public List<com.mindiii.lasross.addtocart.model.AddCart.CartBean.ItemsBean> getItems() {
            return items;
        }

        public void setItems(List<com.mindiii.lasross.addtocart.model.AddCart.CartBean.ItemsBean> items) {
            this.items = items;
        }

        public static class ItemsBean {
            private String key;
            private int productId;
            private int variation_id;
            private int quantity;
            private String subtotal;
            private String tax;
            private String total;
            private String post_title;
            private String slug;
            private String stock_status;
            private String category;
            private String featuredImage;
            private List<?> variation;

            public String getKey() {
                return key;
            }

            public void setKey(String key) {
                this.key = key;
            }

            public int getProductId() {
                return productId;
            }

            public void setProductId(int productId) {
                this.productId = productId;
            }

            public int getVariation_id() {
                return variation_id;
            }

            public void setVariation_id(int variation_id) {
                this.variation_id = variation_id;
            }

            public int getQuantity() {
                return quantity;
            }

            public void setQuantity(int quantity) {
                this.quantity = quantity;
            }

            public String getSubtotal() {
                return subtotal;
            }

            public void setSubtotal(String subtotal) {
                this.subtotal = subtotal;
            }

            public String getTax() {
                return tax;
            }

            public void setTax(String tax) {
                this.tax = tax;
            }

            public String getTotal() {
                return total;
            }

            public void setTotal(String total) {
                this.total = total;
            }

            public String getPost_title() {
                return post_title;
            }

            public void setPost_title(String post_title) {
                this.post_title = post_title;
            }

            public String getSlug() {
                return slug;
            }

            public void setSlug(String slug) {
                this.slug = slug;
            }

            public String getStock_status() {
                return stock_status;
            }

            public void setStock_status(String stock_status) {
                this.stock_status = stock_status;
            }

            public String getCategory() {
                return category;
            }

            public void setCategory(String category) {
                this.category = category;
            }

            public String getFeaturedImage() {
                return featuredImage;
            }

            public void setFeaturedImage(String featuredImage) {
                this.featuredImage = featuredImage;
            }

            public List<?> getVariation() {
                return variation;
            }

            public void setVariation(List<?> variation) {
                this.variation = variation;
            }
        }
    }
}
