package com.mindiii.lasross.addtocart.model;

public class ColorModel {

    int colorCode;

    public ColorModel(int colorCode) {
        this.colorCode = colorCode;
    }

    public int getColorCode() {
        return colorCode;
    }
}
