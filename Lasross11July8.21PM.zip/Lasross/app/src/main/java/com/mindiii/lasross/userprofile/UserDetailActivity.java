package com.mindiii.lasross.userprofile;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.mindiii.lasross.R;

public class UserDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_detail_activity_layout);
    }
}
