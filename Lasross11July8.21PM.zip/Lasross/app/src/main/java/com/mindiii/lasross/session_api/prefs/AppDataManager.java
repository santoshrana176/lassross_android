package com.mindiii.lasross.session_api.prefs;

import android.app.Activity;
import android.content.Context;

import com.androidnetworking.common.ANRequest;
import com.mindiii.lasross.sessionNew.UserInfo;
import com.mindiii.lasross.session_api.prefs.newPrefs.AppPrefrencesHelper;
import com.mindiii.lasross.session_api.prefs.newPrefs.PreferencesHelper;
import com.mindiii.lasross.session_api.prefs.remote.ApiHelper;
import com.mindiii.lasross.session_api.prefs.remote.AppApiHelper;

import java.util.HashMap;

public class AppDataManager implements PreferencesHelper, ApiHelper {//implements DataManager {

    private static AppDataManager instance;
    private final ApiHelper mApiHelper;
    private final PreferencesHelper mPreferencesHelper;

    private AppDataManager(Context context) {
        mPreferencesHelper = new AppPrefrencesHelper(context);
        mApiHelper = AppApiHelper.getAppApiInstance();
    }

    public synchronized static AppDataManager getInstance(Context context) {
        if (instance == null) {
            instance = new AppDataManager(context);
        }
        return instance;
    }

    @Override
    public ANRequest doServerLogin(HashMap<String, String> params) {
        return mApiHelper.doServerLogin(params);
    }

    @Override
    public ANRequest doServerRegistration(HashMap<String, String> params) {
        return mApiHelper.doServerRegistration(params);
    }

    @Override
    public ANRequest logout(HashMap<String, String> header) {
        return mApiHelper.logout(header);
    }

    @Override
    public ANRequest getForgotPassword(HashMap<String, String> params) {
        return mApiHelper.getForgotPassword(params);
    }

    @Override
    public ANRequest getHomeProductCategory(HashMap<String, String> params) {
        return mApiHelper.getHomeProductCategory(params);
    }

    @Override
    public ANRequest getHomeProduct(HashMap<String, String> params) {
        return mApiHelper.getHomeProduct(params);
    }

    @Override
    public ANRequest getMenuList(HashMap<String, String> params) {
        return mApiHelper.getMenuList(params);
    }

    @Override
    public ANRequest getProductDetail(HashMap<String, String> header, HashMap<String, String> params) {
        return mApiHelper.getProductDetail(header,params);
    }

    @Override
    public ANRequest getSocialLogin(HashMap<String, String> params) {
        return mApiHelper.getSocialLogin(params);
    }

    @Override
    public ANRequest doProfileimageUpdate(HashMap<String, String>  header,HashMap<String, String> params) {
        return mApiHelper.doProfileimageUpdate(header, params);
    }

    @Override
    public ANRequest doProfileUpdate(HashMap<String, String>  header, HashMap<String, String> params) {
        return mApiHelper.doProfileUpdate(header, params);
    }

    @Override
    public ANRequest doChangePassword(HashMap<String, String>  header, HashMap<String, String> params) {
        return mApiHelper.doChangePassword(header,params);
    }

    @Override
    public ANRequest getUserProfile(HashMap<String, String> header, HashMap<String, String> params) {
        return mApiHelper.getUserProfile(header,params);
    }

    @Override
    public ANRequest doAddToCart(HashMap<String, String> header, HashMap<String, String> params) {
        return mApiHelper.doAddToCart(header,params);
    }

    @Override
    public ANRequest getCart(HashMap<String, String> header) {
        return mApiHelper.getCart(header);
    }

    @Override
    public ANRequest doRemoveCartItem(HashMap<String, String> header, HashMap<String, String> params) {
        return mApiHelper.doRemoveCartItem(header,params);
    }

    @Override
    public ANRequest doUpdateCartItem(HashMap<String, String> header, HashMap<String, String> params) {
        return mApiHelper.doUpdateCartItem(header,params);
    }

    @Override
    public Boolean isPreLoggedIn() {
        return mPreferencesHelper.isPreLoggedIn();
    }

    @Override
    public UserInfo getUserInfo() {
        return mPreferencesHelper.getUserInfo();
    }

    @Override
    public void setUserInfo(UserInfo userInfo) {
        mPreferencesHelper.setUserInfo(userInfo);
    }

    @Override
    public HashMap<String, String> getHeader() {
        return mPreferencesHelper.getHeader();
    }

    @Override
    public void logout(Activity activity) {
        mPreferencesHelper.logout(activity);
    }
}
