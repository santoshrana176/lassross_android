package com.mindiii.lasross.interfc;


public interface WishlistListener {
    void onClick();
}
