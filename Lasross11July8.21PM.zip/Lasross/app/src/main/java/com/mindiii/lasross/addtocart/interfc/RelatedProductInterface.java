package com.mindiii.lasross.addtocart.interfc;

public interface RelatedProductInterface {
    void onClickListener(int position);
}
