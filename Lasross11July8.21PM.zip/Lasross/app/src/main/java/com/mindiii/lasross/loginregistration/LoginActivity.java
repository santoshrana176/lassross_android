package com.mindiii.lasross.loginregistration;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.util.Base64;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;

import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.StringRequestListener;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.tasks.Task;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.mindiii.lasross.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;

import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import com.mindiii.lasross.base.BaseActivity;
import com.mindiii.lasross.helper.Util;
import com.mindiii.lasross.home.HomeActivity;
import com.mindiii.lasross.sessionNew.Session;
import com.mindiii.lasross.sessionNew.UserInfo;
import com.mindiii.lasross.utils.CommonUtils;

public class LoginActivity extends BaseActivity implements View.OnClickListener, GoogleApiClient.OnConnectionFailedListener {
    private static final String EMAIL = "email";
    private static final int REQ_CODE_GOOGLE = 9001;
    String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
    private TextView tvSignUp, tvForgotPass, tvSignIn;
    private LinearLayout linearLayout, llGoogle;//, llFacebook, llGoogle;
    private EditText etEmail, etPass;
    private CallbackManager callbackManager;
    private ProgressDialog progressDialog;
    private Session session;
    private LoginButton loginButton;
    private Gson gson;
    private GsonBuilder gsonBuilder;
    private GoogleApiClient googleApiClient;
    private GoogleSignInClient googleSignInClient;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_form);

        llGoogle = findViewById(R.id.llGoogle);
        linearLayout = findViewById(R.id.linearLayout);

        gsonBuilder = new GsonBuilder();
        gson = gsonBuilder.create();
        session = new Session(this);

        GoogleSignInOptions signInOptions = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();

        googleApiClient = new GoogleApiClient.Builder(this)
                .enableAutoManage(this, this)
                .addApi(Auth.GOOGLE_SIGN_IN_API, signInOptions)
                .build();

        googleSignInClient = GoogleSignIn.getClient(this, signInOptions);

        llGoogle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent signInIntent = googleSignInClient.getSignInIntent();
                startActivityForResult(signInIntent, REQ_CODE_GOOGLE);
            }
        });

        try {
            PackageInfo info = getPackageManager().getPackageInfo(getPackageName(), PackageManager.GET_SIGNATURES);

            for (Signature signature : info.signatures) {
                MessageDigest md = MessageDigest.getInstance("SHA");
                md.update(signature.toByteArray());
                String hashKey = new String(Base64.encode(md.digest(), 0));
            }
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }

        Window window = this.getWindow();
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(this.getResources().getColor(R.color.home_header_bg1));

        progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);

        loginButton = findViewById(R.id.login_button);

        loginButton.setReadPermissions(Arrays.asList(EMAIL));

        callbackManager = CallbackManager.Factory.create();

        AccessToken accessToken = AccessToken.getCurrentAccessToken();
        boolean isLoggedIn = accessToken != null && !accessToken.isExpired();

        loginButton.registerCallback(callbackManager, new FacebookCallback<LoginResult>() {

            @Override
            public void onSuccess(LoginResult loginResult) {
                //etEmail.setText("Login successfull" + loginResult.getAccessToken().getUserId());
            }

            @Override
            public void onCancel() {
                //etEmail.setText("Login cancel");
            }

            @Override
            public void onError(FacebookException exception) {

            }
        });

        /*if (getCurrentFocus() != null) {
            InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            inputMethodManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        }*/

        tvSignUp = findViewById(R.id.tvSignUp);
        tvForgotPass = findViewById(R.id.tvForgotPass);
        tvSignIn = findViewById(R.id.tvSignIn);

        etEmail = findViewById(R.id.etEmail);
        etPass = findViewById(R.id.etPass);

        tvForgotPass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openForgetPasswordDialog();
            }
        });

        tvSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this, RegistrationActivity.class));
                finish();
            }
        });

        printHashKey(this);

        /*etEmail.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    hideKeyboard();
                }
            }
        });*/

        linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                InputMethodManager inputMethodManager = (InputMethodManager)
                        view.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
            }
        });


        tvSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = etEmail.getText().toString().trim();
                String pass = etPass.getText().toString().trim();

                try {
                    InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
                } catch (Exception e) {

                }

                if (email.equals("")) {
                    CommonUtils.showCustomAlert(LoginActivity.this,"Please enter email");
                    //etEmail.setError("Please enter email");
                    return;
                } else if (pass.equals("")) {
                    CommonUtils.showCustomAlert(LoginActivity.this,"Please enter password");
                    //etPass.setError("Please enter password");
                    return;
                }

                if (isValidEmail(email) && isValidPass(pass)) {
                    validateDataForLoginApi(email, pass, v);
                } else if (!isValidEmail(email)) {
                    CommonUtils.showCustomAlert(LoginActivity.this,"Please enter valid email");
                    //etEmail.setError("Please enter valid email");
                } else if (!isValidPass(pass)) {
                    CommonUtils.showCustomAlert(LoginActivity.this,"Password should have minimum 6 characters");
                    //etPass.setError("Password should have minimum 6 characters");
                }
            }
        });

    }


    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(etEmail.getWindowToken(), 0);
    }

    /*@Override
    protected void onStart() {
        super.onStart();
        GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(this);
    }*/

    public void fbLogin(View view) {
        //LoginManager.getInstance().logInWithReadPermissions(this, Arrays.asList("user_photos", "email", "public_profile", "user_posts"));
        //LoginManager.getInstance().logInWithPublishPermissions(this, Arrays.asList("publish_actions"));
        LoginManager.getInstance().logInWithReadPermissions(this, Collections.singletonList(EMAIL));
        LoginManager.getInstance().registerCallback(callbackManager,
                new FacebookCallback<LoginResult>() {
                    @Override
                    public void onSuccess(LoginResult loginResult) {
                        //etEmail.setText("Login successfull" +loginResult.getAccessToken().getUserId());
                        etEmail.setText("Login successfull");
                        final GraphRequest request = GraphRequest.newMeRequest(
                                loginResult.getAccessToken(),
                                new GraphRequest.GraphJSONObjectCallback() {

                                    @Override
                                    public void onCompleted(JSONObject object, GraphResponse response) {
                                        try {
                                            String name = object.getString("name");
                                            String email = object.getString("email");
                                            String id = object.getString("id");
                                            JSONObject picture = object.getJSONObject("picture");
                                            JSONObject data = picture.getJSONObject("data");
                                            String url = data.getString("url");
                                            validateSocialLogin(name, email, id, url, "facebook");

                                        } catch (Exception e) {
                                            progressDialog.dismiss();
                                        }
                                    }
                                });
                        Bundle parameters = new Bundle();
                        parameters.putString("fields", "name,email,id,picture");
                        request.setParameters(parameters);
                        request.executeAsync();
                    }

                    @Override
                    public void onCancel() {
                        etEmail.setText("Login cancel");
                        //tvNameEmail.setText("Login cancel");
                    }

                    @Override
                    public void onError(FacebookException exception) {
                    }
                });
    }

    private void validateSocialLogin(final String name, final String email, final String id,
                                     final String url, final String type) {
        if (CommonUtils.isNetworkAvailable(LoginActivity.this)) {
            HashMap<String, String> paramas = new HashMap();
            paramas.put("username", name);
            paramas.put("email", email);
            paramas.put("display_name", name);
            paramas.put("socialType", type);
            paramas.put("socialId", id);
            paramas.put("socialImageUrl", url);

            getDataManager().getSocialLogin(paramas).getAsString(new StringRequestListener() {
                @Override
                public void onResponse(String response) {

                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        String status = jsonObject.getString("status");

                        if (status.equals("ok")) {
                            progressDialog.dismiss();
                            JSONObject object = jsonObject.getJSONObject("user");
                            String id = object.getString("id");
                            UserInfo userInfo = new UserInfo();
                            userInfo.cookie = jsonObject.getString("cookie");
                            userInfo.first_name = object.getString("firstname");
                            userInfo.email = object.getString("email");
                            userInfo.last_name = object.getString("lastname");
                            userInfo.profile_image = object.getString("avatar_url_full");
                            userInfo.description = object.getString("description");
                            userInfo.social_type = type;

                            session.createSession(userInfo);
                            if (session != null) {
                                Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
                                intent.putExtra("type", type);
                                startActivity(intent);
                                finish();
                                finishAffinity();
                            }
                        } else if (status.equals("error")) {
                            progressDialog.dismiss();
                            String error = jsonObject.getString("error");
                            Toast.makeText(LoginActivity.this, error, Toast.LENGTH_LONG).show();
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                        progressDialog.dismiss();
                    }
                }

                @Override
                public void onError(ANError anError) {
                    progressDialog.dismiss();
                    Util.parseError(getBaseContext(), anError);

                    if (anError.getErrorCode() == 0) {
                        CommonUtils.showCustomAlert(LoginActivity.this,"No Internet Connection");
                        //Toast.makeText(LoginActivity.this, "No Internet Connection", Toast.LENGTH_LONG).show();
                    } else if (anError.getErrorCode() == 404)
                        CommonUtils.showCustomAlert(LoginActivity.this,"Invalid authentication");
                        //Toast.makeText(LoginActivity.this, "Invalid authentication", Toast.LENGTH_LONG).show();
                }
            });
        }
        else {
            toastMessage("No Internet Connection");
        }
    }

    private void validateDataForLoginApi(final String email, final String pass, final View v) {

        if (CommonUtils.isNetworkAvailable(LoginActivity.this)) {
            progressDialog.show();
            progressDialog.setMessage("loading.....");

            HashMap<String, String> paramas = new HashMap();
            paramas.put("email", email);
            paramas.put("password", pass);

            getDataManager().doServerLogin(paramas).getAsString(new StringRequestListener() {
                @Override
                public void onResponse(String response) {
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        String status = jsonObject.getString("status");

                        if (status.equals("ok")) {
                            progressDialog.dismiss();

                            String cookie = jsonObject.getString("cookie");
                            JSONObject object = jsonObject.getJSONObject("user");
                            String id = object.getString("id");
                            String firstname = object.getString("firstname");
                            String lastname = object.getString("lastname");
                            String email = object.getString("email");
                            String profile_image = object.getString("avatar_url_full");
                            String description;
                            description = object.getString("description");
                            UserInfo userInfo = new UserInfo();
                            userInfo.cookie = cookie;
                            userInfo.first_name = firstname;
                            userInfo.email = email;
                            userInfo.last_name = lastname;
                            userInfo.profile_image = profile_image;
                            userInfo.description = description;
                            session.createSession(userInfo);
                            startActivity(new Intent(LoginActivity.this, HomeActivity.class));
                            finish();
                        } else if (status.equals("error")) {
                            progressDialog.dismiss();
                            String error = jsonObject.getString("error");
                            CommonUtils.showCustomAlert(LoginActivity.this,error);
                            //Toast.makeText(LoginActivity.this, error, Toast.LENGTH_LONG).show();
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                        progressDialog.dismiss();
                    }
                }

                @Override
                public void onError(ANError anError) {
                    progressDialog.dismiss();
                    Util.parseError(getBaseContext(), anError);

                    if (anError.getErrorCode() == 0) {
                        CommonUtils.showCustomAlert(LoginActivity.this,"No Internet Connection");
                        //Toast.makeText(LoginActivity.this, "No Internet Connection", Toast.LENGTH_LONG).show();
                    } else
                        CommonUtils.showCustomAlert(LoginActivity.this,"Email does not exist");
                        //Toast.makeText(LoginActivity.this, "email does not exist", Toast.LENGTH_LONG).show();
                }
            });


        } else {
            CommonUtils.showCustomAlert(LoginActivity.this,"No Internet Connection");
        }
    }

    private void gmailLogin(View view) {
        Intent intent = googleSignInClient.getSignInIntent();
        startActivityForResult(intent, REQ_CODE_GOOGLE);
    }

    public void printHashKey(Context pContext) {
        String TAG = "";
        try {
            PackageInfo info = getPackageManager().getPackageInfo(getPackageName(), PackageManager.GET_SIGNATURES);
            for (Signature signature : info.signatures) {
                MessageDigest md = MessageDigest.getInstance("SHA");
                md.update(signature.toByteArray());
                String hashKey = new String(Base64.encode(md.digest(), 0));
            }
        } catch (NoSuchAlgorithmException e) {
        } catch (Exception e) {
        }
    }

    private void openForgetPasswordDialog() {

        final Dialog dialog = new Dialog(LoginActivity.this);//,android.R.style.Theme_Dialog);
        dialog.setContentView(R.layout.forgot_password_dialog_artboard_2_1);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        final EditText etEmailID;
        TextView tvSend;
        ImageView ivClose;
        etEmailID = dialog.findViewById(R.id.etEmailID);
        tvSend = dialog.findViewById(R.id.tvSend);
        ivClose = dialog.findViewById(R.id.ivClose);
        ivClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        tvSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String email = etEmailID.getText().toString();
                if (isValidEmail(email)) {
                    validPasswordDetail(email, dialog);
                } else if (!isValidEmail(email)) {
                    etEmailID.setError("Invalid email");
                }
            }
        });

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(dialog.getWindow().getAttributes());
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        lp.gravity = Gravity.TOP;
        lp.windowAnimations = R.style.DialogAnimation;
        dialog.getWindow().setAttributes(lp);

        dialog.setCanceledOnTouchOutside(false);

        dialog.show();
    }

    private void validPasswordDetail(String email, final Dialog dialog) {

        if (CommonUtils.isNetworkAvailable(LoginActivity.this)) {
            progressDialog.show();
            progressDialog.setMessage("loading.....");

            HashMap<String, String> params = new HashMap<>();
            params.put("email", email);

            getDataManager().getForgotPassword(params).getAsString(new StringRequestListener() {
                @Override
                public void onResponse(String response) {
                    try {
                        JSONObject jsonObject = new JSONObject(response);

                        String status = jsonObject.getString("status");
                        if (status.equals("ok")) {
                            progressDialog.dismiss();
                            String msg = jsonObject.getString("msg");
                            CommonUtils.showCustomAlert(LoginActivity.this,msg);
                            dialog.dismiss();
                            //Toast.makeText(LoginActivity.this, msg, Toast.LENGTH_LONG).show();
                        } else if (status.equals("error")) {
                            progressDialog.dismiss();
                            String error = jsonObject.getString("error");
                            CommonUtils.showCustomAlert(LoginActivity.this,error);
                            //Toast.makeText(LoginActivity.this, error, Toast.LENGTH_LONG).show();
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onError(ANError anError) {
                    progressDialog.dismiss();
                    CommonUtils.showCustomAlert(LoginActivity.this,"Your email address not found!");
                    //Toast.makeText(LoginActivity.this, "Your email address not found!", Toast.LENGTH_LONG).show();
                }
            });
        } else {
            CommonUtils.showCustomAlert(LoginActivity.this,"No Internet Connection");
            //toastMessage("No Internet Connection");
        }
    }

    private boolean isValidEmail(String email) {
        return email.matches(emailPattern);
    }

    private boolean isValidPass(String pass) {
        return pass.length() > 5;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_CODE_GOOGLE) {

            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            handleresult(task);
        } else
            callbackManager.onActivityResult(requestCode, resultCode, data);
    }

    private void handleresult(Task<GoogleSignInAccount> completedTask) {
        try {
            GoogleSignInAccount account = completedTask.getResult(ApiException.class);

            String name = account.getDisplayName();
            String email = account.getEmail();
            String id = account.getId();
            String url = String.valueOf(account.getPhotoUrl());
            String displayName = account.getAccount().name;

            validateSocialLogin(name, email, id, url, "gmail");

            //etEmail.setText(email);
        } catch (ApiException e) {
        }
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.llGoogle:
                //signIn();
                break;
        }
    }

    private void signIn() {
        Intent intent = googleSignInClient.getSignInIntent();
        startActivityForResult(intent, REQ_CODE_GOOGLE);
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }
}
