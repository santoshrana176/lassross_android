package com.mindiii.lasross.addtocart.model;

import java.util.List;

public class AvailableColor {
    private List<GreenBean> green;
    private List<BlueBean> blue;

    public List<GreenBean> getGreen() {
        return green;
    }

    public void setGreen(List<GreenBean> green) {
        this.green = green;
    }

    public List<BlueBean> getBlue() {
        return blue;
    }

    public void setBlue(List<BlueBean> blue) {
        this.blue = blue;
    }

    public static class GreenBean {
        private int variation_id;
        private String size;

        public int getVariation_id() {
            return variation_id;
        }

        public void setVariation_id(int variation_id) {
            this.variation_id = variation_id;
        }

        public String getSize() {
            return size;
        }

        public void setSize(String size) {
            this.size = size;
        }
    }

    public static class BlueBean {
        /**
         * variation_id : 1339
         * size : large
         */

        private int variation_id;
        private String size;

        public int getVariation_id() {
            return variation_id;
        }

        public void setVariation_id(int variation_id) {
            this.variation_id = variation_id;
        }

        public String getSize() {
            return size;
        }

        public void setSize(String size) {
            this.size = size;
        }
    }
}
