package com.mindiii.lasross.loginregistration;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;

import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.StringRequestListener;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.tasks.Task;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.mindiii.lasross.R;
import com.mindiii.lasross.base.BaseActivity;
import com.mindiii.lasross.helper.Util;
import com.mindiii.lasross.home.HomeActivity;
import com.mindiii.lasross.loginregistration.model.RegistrationModal;
import com.mindiii.lasross.sessionNew.Session;
import com.mindiii.lasross.sessionNew.UserInfo;
import com.mindiii.lasross.utils.CommonUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.regex.Pattern;

public class RegistrationActivity extends BaseActivity implements View.OnClickListener, GoogleApiClient.OnConnectionFailedListener{
    private TextView tvSignUp, tvForgotPass, tvSignIn;
    private EditText etFullName, etEmail, etPass;
    private LinearLayout llImage;
    private LinearLayout linearLayout, llGoogle;//, llFacebook, llGoogle;
    private Pattern pattern;
    private ProgressDialog progressDialog;
    private Session session;
    private String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
    private GoogleApiClient googleApiClient;
    private GoogleSignInClient googleSignInClient;
    private Gson gson;
    private GsonBuilder gsonBuilder;
    private static final int REQ_CODE_GOOGLE = 9001;
    private static final String EMAIL = "email";
    private CallbackManager callbackManager;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registration_form);
        progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);
        callbackManager = CallbackManager.Factory.create();

        llGoogle = findViewById(R.id.llGoogle);
        linearLayout = findViewById(R.id.linearLayout);
        gsonBuilder = new GsonBuilder();
        gson = gsonBuilder.create();

        linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                InputMethodManager inputMethodManager = (InputMethodManager)
                        view.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
            }
        });

        Window window = this.getWindow();
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(this.getResources().getColor(R.color.home_header_bg1));

        progressDialog = new ProgressDialog(this);
        llImage = findViewById(R.id.llImage);

        GoogleSignInOptions signInOptions = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();

        googleApiClient = new GoogleApiClient.Builder(this)
                .enableAutoManage(this,this)
                .addApi(Auth.GOOGLE_SIGN_IN_API, signInOptions)
                .build();

        googleSignInClient  = GoogleSignIn.getClient(this,signInOptions);

        llGoogle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent signInIntent = googleSignInClient.getSignInIntent();
                startActivityForResult(signInIntent, REQ_CODE_GOOGLE);
            }
        });

        session = new Session(this);

        Calendar c = Calendar.getInstance();
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss");
        final String formattedDate = df.format(c.getTime());
        Log.e("date is ", formattedDate);

        pattern = Pattern.compile("^[a-zA-Z ]+$");

        tvSignIn = findViewById(R.id.tvSignIn);
        tvSignUp = findViewById(R.id.tvSignUp);

        etFullName = findViewById(R.id.etFullName);
        etEmail = findViewById(R.id.etEmail);
        etPass = findViewById(R.id.etPass);

        tvSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(RegistrationActivity.this, LoginActivity.class));
                finish();
            }
        });

        tvSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = etFullName.getText().toString();
                String email = etEmail.getText().toString();
                String pass = etPass.getText().toString();

                try {
                    InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                if (name.equals("")) {
                    CommonUtils.showCustomAlert(RegistrationActivity.this,"Please enter full name");
                    return;
                } else if (name.length()<3) {
                    CommonUtils.showCustomAlert(RegistrationActivity.this,"Full name should not less than 2 characters");
                    //etEmail.setError("Enter email");
                    return;
                } else if (email.equals("")) {
                    CommonUtils.showCustomAlert(RegistrationActivity.this,"Please enter email");
                    //etEmail.setError("Enter email");
                    return;
                } else if (pass.equals("")) {
                    CommonUtils.showCustomAlert(RegistrationActivity.this,"Please enter password");
                    return;
                }

                if (isValidEmail(email) && isValidPass(pass) && isValidName(name)) {
                    validateData(name, email, pass, formattedDate, v);
                } else if (!isValidName(name)) {
                    CommonUtils.showCustomAlert(RegistrationActivity.this,"Only alphabets are allowed in full name");
                } else if (!isValidEmail(email)) {
                    CommonUtils.showCustomAlert(RegistrationActivity.this,"Please enter valid email");
                    //etEmail.setError("Please enter valid email");
                } else if (!isValidPass(pass)) {
                    CommonUtils.showCustomAlert(RegistrationActivity.this,"Password should have minimum 6 characters");
                    //etPass.setError("Password should have minimum 6 characters");
                }
            }
        });
    }

    public void fbLogin(View view) {
        LoginManager.getInstance().logInWithReadPermissions(this, Collections.singletonList(EMAIL));
        LoginManager.getInstance().registerCallback(callbackManager,
                new FacebookCallback<LoginResult>() {
                    @Override
                    public void onSuccess(LoginResult loginResult) {
                        //etEmail.setText("Login successfull" +loginResult.getAccessToken().getUserId());
                        etEmail.setText("Login successfull");
                        final GraphRequest request = GraphRequest.newMeRequest(
                                loginResult.getAccessToken(),
                                new GraphRequest.GraphJSONObjectCallback() {

                                    @Override
                                    public void onCompleted(JSONObject object, GraphResponse response) {
                                        Log.e("Main", response.toString());
                                        try {
                                            String name = object.getString("name");
                                            String email = object.getString("email");
                                            String id = object.getString("id");
                                            JSONObject picture = object.getJSONObject("picture");
                                            JSONObject data = picture.getJSONObject("data");
                                            String url = data.getString("url");
                                            validateSocialLogin(name,email,id,url,"facebook");
                                        } catch (Exception e) {
                                            progressDialog.dismiss();
                                        }
                                    }
                                });
                        Bundle parameters = new Bundle();
                        parameters.putString("fields", "name,email,id,picture");
                        request.setParameters(parameters);
                        request.executeAsync();
                    }

                    @Override
                    public void onCancel() {
                        etEmail.setText("Login cancel");
                        //tvNameEmail.setText("Login cancel");
                    }

                    @Override
                    public void onError(FacebookException exception) {
                    }
                });
    }

    private void validateSocialLogin(final String name, final String email, final String id, final String url, final String type) {

        if (CommonUtils.isNetworkAvailable(RegistrationActivity.this)) {
            //progressDialog.show();
            //progressDialog.setMessage("loading.....");

            HashMap<String, String> paramas = new HashMap();
            paramas.put("username", name);
            paramas.put("email", email);
            paramas.put("display_name", name);
            paramas.put("socialType", type);
            paramas.put("socialId", id);
            paramas.put("socialImageUrl", url);

            getDataManager().getSocialLogin(paramas).getAsString(new StringRequestListener() {
                @Override
                public void onResponse(String response) {

                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        String status = jsonObject.getString("status");

                        if (status.equals("ok")) {
                            progressDialog.dismiss();
                            JSONObject object = jsonObject.getJSONObject("user");
                            String id = object.getString("id");
                            UserInfo userInfo = new UserInfo();
                            userInfo.cookie = jsonObject.getString("cookie");
                            userInfo.first_name = object.getString("firstname");
                            userInfo.email = object.getString("email");
                            userInfo.last_name = object.getString("lastname");
                            userInfo.profile_image = object.getString("avatar_url_full");
                            userInfo.description = object.getString("description");
                            userInfo.social_type = type;

                            session.createSession(userInfo);
                            if (session != null) {
                                Intent intent = new Intent(RegistrationActivity.this, HomeActivity.class);
                                intent.putExtra("type", type);
                                startActivity(intent);
                                finish();
                                finishAffinity();
                            }
                        } else if (status.equals("error")) {
                            progressDialog.dismiss();
                            String error = jsonObject.getString("error");
                            CommonUtils.showCustomAlert(RegistrationActivity.this,error);
                            //Toast.makeText(RegistrationActivity.this, error, Toast.LENGTH_LONG).show();
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                        progressDialog.dismiss();
                    }
                }

                @Override
                public void onError(ANError anError) {
                    progressDialog.dismiss();
                    Util.parseError(getBaseContext(), anError);

                    if (anError.getErrorCode() == 0) {
                        Toast.makeText(RegistrationActivity.this, "No Internet Connection", Toast.LENGTH_LONG).show();
                    } else if (anError.getErrorCode() == 404)
                        CommonUtils.showCustomAlert(RegistrationActivity.this,"Invalid authentication");
                        //Toast.makeText(RegistrationActivity.this, "Invalid authentication", Toast.LENGTH_LONG).show();
                }
            });
        }
        else {
            CommonUtils.showCustomAlert(RegistrationActivity.this,"No internet connection");
        }
    }

    private void validateData(final String fullName, final String email, final String pass, final String formattedDate, final View v) {
        if (CommonUtils.isNetworkAvailable(RegistrationActivity.this)) {
            progressDialog.show();
            progressDialog.setMessage("loading.....");
            HashMap<String, String>params = new HashMap();
            params.put("email",email);
            params.put("password",pass);
            params.put("username",email);
            params.put("display_name",fullName);

            getDataManager().doServerRegistration(params).getAsString(new StringRequestListener() {
                @Override
                public void onResponse(String response) {
                    RegistrationModal registrationModal = gson.fromJson(response, RegistrationModal.class);
                    RegistrationModal.UserBean userBean = registrationModal.getUser();
                    if (registrationModal.getStatus().equals("ok")) {
                        progressDialog.dismiss();
                        UserInfo userInfo = new UserInfo();
                        userInfo.cookie = registrationModal.getCookie();
                        userInfo.userId = String.valueOf(userBean.getId());
                        userInfo.first_name = userBean.getFirstname();
                        userInfo.last_name = userBean.getLastname();
                        userInfo.email = userBean.getEmail();
                        userInfo.profile_image = userBean.getAvatar_url_full();
                        userInfo.description = userBean.getDescription();
                        session.createSession(userInfo);
                        //getDataManager().setUserInfo(userInfo);
                        Snackbar snackbar = Snackbar
                                .make(v, "Successfully registered", Snackbar.LENGTH_INDEFINITE)
                                .setAction("Done", new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        startActivity(new Intent(RegistrationActivity.this, HomeActivity.class));
                                        finish();
                                    }
                                });
                        snackbar.show();
                    }else{
                        progressDialog.dismiss();
                        //String error = registrationModal.getString("error");
                        CommonUtils.showCustomAlert(RegistrationActivity.this,"Something went wrong");
                        // Toast.makeText(RegistrationActivity.this, "SomeThing went wrong.", Toast.LENGTH_LONG).show();
                    }
                }

                @Override
                public void onError(ANError anError) {
                    progressDialog.dismiss();
                    CommonUtils.showCustomAlert(RegistrationActivity.this,"E-mail address is already in use.");
                    //Toast.makeText(RegistrationActivity.this, "E-mail address is already in use.", Toast.LENGTH_LONG).show();
                }
            });
        }

        else {
            toastMessage("No Internet Connection");
        }
    }

    private boolean isValidEmail(String email) {
        return email.matches(emailPattern);
    }

    private boolean isValidPass(String pass) {
        return pass.length() > 5;
    }

    private boolean isValidName(String lName) {
        return pattern.matcher(lName).matches();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_CODE_GOOGLE) {

            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            handleresult(task);
        } else
            callbackManager.onActivityResult(requestCode, resultCode, data);
    }

    private void handleresult(Task<GoogleSignInAccount> completedTask) {
        try {
            Log.e("handler result","its working");
            GoogleSignInAccount account = completedTask.getResult(ApiException.class);

            String name = account.getDisplayName();
            String email = account.getEmail();
            String id = account.getId();
            String url = String.valueOf(account.getPhotoUrl());
            String displayName = account.getAccount().name;

            validateSocialLogin(name,email,id,url,"gmail");
        } catch (ApiException e) {

            Log.e("", "signInResult:failed code=" + e.getStatusCode());
        }
    }

    @Override
    public void onClick(View view) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }
}
